import React, { useState, useMemo } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider, useCart } from './context/CartContext';
import { BrandProvider, useBrand } from './context/BrandContext';
import { SAMPLE_PRODUCTS } from './data/products';
import { Product } from './types';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { AuthModal } from './components/AuthModal';
import { UserProfileDrawer } from './components/UserProfileDrawer';
import { WishlistModal } from './components/WishlistModal';
import { MemberPerksBanner } from './components/MemberPerksBanner';
import { BrandEditorModal } from './components/BrandEditorModal';
import { Dashboard } from './components/Dashboard';
import { Footer } from './components/Footer';
import { SlidersHorizontal, Sparkles, Flame, UserPlus, LogIn, ArrowUpDown, Tag } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { user, isAuthenticated, openAuthModal } = useAuth();
  const { selectedProductForQuickView, setSelectedProductForQuickView } = useCart();

  const [currentView, setCurrentView] = useState<'shop' | 'dashboard'>('shop');
  const [selectedCategory, setSelectedCategory] = useState<string>('All Drops');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [filterTag, setFilterTag] = useState<string>('all');
  const [isWishlistModalOpen, setIsWishlistModalOpen] = useState(false);


  // Filtered and sorted products
  const filteredProducts = useMemo(() => {
    return SAMPLE_PRODUCTS.filter((prod) => {
      // Category filter
      const matchesCategory =
        selectedCategory === 'All Drops' || prod.category === selectedCategory;

      // Search query filter
      const matchesSearch =
        searchQuery === '' ||
        prod.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prod.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prod.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prod.description.toLowerCase().includes(searchQuery.toLowerCase());

      // Tag filter
      const matchesTag =
        filterTag === 'all' || (prod.tag && prod.tag.includes(filterTag));

      return matchesCategory && matchesSearch && matchesTag;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // featured default
    });
  }, [selectedCategory, searchQuery, filterTag, sortBy]);

  const handleExploreClick = () => {
    const el = document.getElementById('catalog-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSneakersClick = () => {
    setSelectedCategory('Sneakers');
    const el = document.getElementById('catalog-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#0c0d0e] text-neutral-100 flex flex-col font-sans selection:bg-amber-400 selection:text-black">
      {/* Top Navbar */}
      <Navbar
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedCategory={selectedCategory}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          setCurrentView('shop');
        }}
        onOpenWishlistModal={() => setIsWishlistModalOpen(true)}
        onOpenDashboard={() => setCurrentView('dashboard')}
        isDashboardActive={currentView === 'dashboard'}
      />

      {currentView === 'dashboard' ? (
        <Dashboard
          onBackToStore={() => setCurrentView('shop')}
          onSelectProduct={(p) => setSelectedProductForQuickView(p)}
        />
      ) : (
        <main className="flex-1">
          {/* Hero Editorial Section */}
          <HeroBanner
            onExploreClick={handleExploreClick}
            onSneakersClick={handleSneakersClick}
          />

        {/* User Auth Banner Notice (if not logged in) */}
        {!isAuthenticated && (
          <section className="bg-amber-400/10 border-y border-amber-400/20 py-3.5 px-4 text-center">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 text-amber-300 font-medium">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Sign up now to reserve your size & claim <strong>600 UrbanPoints</strong> welcome bonus.</span>
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => openAuthModal('signup')}
                  className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-black font-extrabold uppercase rounded-lg text-[11px] transition-all flex items-center gap-1 font-display"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Create Account</span>
                </button>
                <button
                  onClick={() => openAuthModal('signin')}
                  className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white font-bold uppercase rounded-lg text-[11px] transition-all flex items-center gap-1 border border-neutral-700"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Sign In</span>
                </button>
              </div>
            </div>
          </section>
        )}

        {/* Catalog Section */}
        <section id="catalog-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Header & Filter Controls */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-neutral-800">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-mono uppercase tracking-widest text-amber-400 font-bold bg-amber-400/10 px-2.5 py-0.5 rounded-full border border-amber-400/20">
                  CURATED DROP
                </span>
                <span className="text-xs text-neutral-500">
                  Showing {filteredProducts.length} pieces
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white uppercase font-display">
                {selectedCategory}
              </h2>
            </div>

            {/* Filter Pills and Sorter */}
            <div className="flex flex-wrap items-center gap-3">
              {/* Tag filters */}
              <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded-2xl p-1 text-xs">
                <button
                  onClick={() => setFilterTag('all')}
                  className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                    filterTag === 'all'
                      ? 'bg-neutral-800 text-white'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setFilterTag('DROP')}
                  className={`px-3 py-1.5 rounded-xl font-semibold transition-all flex items-center gap-1 ${
                    filterTag === 'DROP'
                      ? 'bg-amber-400 text-black font-bold'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <Flame className="w-3 h-3" />
                  <span>Drops</span>
                </button>
                <button
                  onClick={() => setFilterTag('EXCLUSIVE')}
                  className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
                    filterTag === 'EXCLUSIVE'
                      ? 'bg-neutral-800 text-white'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Exclusive
                </button>
              </div>

              {/* Sort selector */}
              <div className="flex items-center gap-1.5 bg-neutral-900 border border-neutral-800 rounded-2xl px-3 py-1.5 text-xs text-neutral-300">
                <ArrowUpDown className="w-3.5 h-3.5 text-neutral-500" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-transparent text-xs text-white focus:outline-none cursor-pointer pr-2"
                >
                  <option value="featured" className="bg-neutral-900">Sort: Featured</option>
                  <option value="price-asc" className="bg-neutral-900">Price: Low to High</option>
                  <option value="price-desc" className="bg-neutral-900">Price: High to Low</option>
                  <option value="rating" className="bg-neutral-900">Highest Rated</option>
                </select>
              </div>
            </div>
          </div>

          {/* Active Search Indicator */}
          {searchQuery && (
            <div className="pt-4 flex items-center justify-between text-xs text-neutral-400">
              <span>
                Search results for: <strong className="text-white">"{searchQuery}"</strong>
              </span>
              <button
                onClick={() => setSearchQuery('')}
                className="text-amber-400 hover:underline"
              >
                Clear Search
              </button>
            </div>
          )}

          {/* Product Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-8">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onSelect={(p) => setSelectedProductForQuickView(p)}
              />
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-20 space-y-3">
              <Tag className="w-10 h-10 text-neutral-600 mx-auto" />
              <h3 className="text-base font-bold text-white uppercase">No items match your criteria</h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Try resetting your search query or selecting "All Drops" to view the entire catalogue.
              </p>
              <button
                onClick={() => {
                  setSelectedCategory('All Drops');
                  setSearchQuery('');
                  setFilterTag('all');
                }}
                className="px-5 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold uppercase rounded-xl transition-colors"
              >
                Reset All Filters
              </button>
            </div>
          )}
        </section>

        {/* VIP Member Perks & Sign Up Promo Banner */}
        <MemberPerksBanner />
      </main>
      )}

      {/* Footer */}
      <Footer />

      {/* Global Modals & Drawers */}
      <AuthModal />
      <BrandEditorModal />
      <UserProfileDrawer onOpenDashboard={() => setCurrentView('dashboard')} />
      <CartDrawer />
      <WishlistModal
        isOpen={isWishlistModalOpen}
        onClose={() => setIsWishlistModalOpen(false)}
        onSelectProduct={(p) => setSelectedProductForQuickView(p)}
      />
      <ProductDetailModal
        product={selectedProductForQuickView}
        onClose={() => setSelectedProductForQuickView(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <BrandProvider>
      <AuthProvider>
        <CartProvider>
          <MainAppContent />
        </CartProvider>
      </AuthProvider>
    </BrandProvider>
  );
}

