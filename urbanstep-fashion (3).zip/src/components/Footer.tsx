import React, { useState } from 'react';
import { Send, CheckCircle2, ShieldCheck, Heart, Sparkles, Edit3 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useBrand } from '../context/BrandContext';

export const Footer: React.FC = () => {
  const { openAuthModal, isAuthenticated } = useAuth();
  const { brand, openBrandEditor } = useBrand();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setSubscribed(true);
  };

  return (
    <footer className="bg-neutral-950 border-t border-neutral-800 text-neutral-400 text-xs">
      {/* Upper Newsletter Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 border-b border-neutral-900">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-6 space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-400">
              {brand.name.toUpperCase()} DISPATCH
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-white uppercase font-display">
              Get Notified 10 Minutes Before Drops Drop
            </h3>
            <p className="text-xs text-neutral-400">
              No spam. Only release countdowns, secret password links, and member invitations.
            </p>
          </div>

          <div className="md:col-span-6">
            {subscribed ? (
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center gap-3 text-emerald-300">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <div>
                  <div className="font-bold">You are on the secret drop list!</div>
                  <div className="text-[11px] text-emerald-400/80">Check your inbox for your 10% welcome code.</div>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <input
                  type="email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="Enter your email address..."
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                  required
                />
                <button
                  type="submit"
                  className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-black font-extrabold uppercase rounded-xl transition-all font-display shrink-0 flex items-center gap-1.5"
                >
                  <span>Join</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Main Links Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {/* Col 1: Brand */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-amber-400 text-black flex items-center justify-center font-black text-xs font-display">
                {brand.monogram}
              </div>
              <span className="font-black text-white text-base font-display uppercase">{brand.name}</span>
            </div>
            <p className="text-[11px] text-neutral-500 leading-relaxed">
              Tokyo & New York fashion collective engineering contemporary urban footwear and modular apparel.
            </p>
          </div>

          {/* Col 2: Collections */}
          <div className="space-y-2">
            <h4 className="text-white font-bold uppercase tracking-wider text-[11px]">Collections</h4>
            <ul className="space-y-1.5 text-[11px]">
              <li><a href="#sneakers" className="hover:text-white transition-colors">Kinetic Sneakers</a></li>
              <li><a href="#outerwear" className="hover:text-white transition-colors">Tactical Parkas</a></li>
              <li><a href="#hoodies" className="hover:text-white transition-colors">Heavyweight Hoodies</a></li>
              <li><a href="#cargo" className="hover:text-white transition-colors">Modular Pants</a></li>
              <li><a href="#accessories" className="hover:text-white transition-colors">Bags & Tech Accs</a></li>
            </ul>
          </div>

          {/* Col 3: Member Services */}
          <div className="space-y-2">
            <h4 className="text-white font-bold uppercase tracking-wider text-[11px]">Member Hub</h4>
            <ul className="space-y-1.5 text-[11px]">
              {!isAuthenticated ? (
                <>
                  <li>
                    <button onClick={() => openAuthModal('signup')} className="text-amber-400 hover:underline">
                      Sign Up for Free (+600 PTS)
                    </button>
                  </li>
                  <li>
                    <button onClick={() => openAuthModal('signin')} className="hover:text-white transition-colors">
                      Member Sign In
                    </button>
                  </li>
                </>
              ) : (
                <li><span className="text-emerald-400">VIP Passport Active</span></li>
              )}
              <li>
                <button
                  onClick={openBrandEditor}
                  className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
                >
                  <Edit3 className="w-3 h-3" />
                  <span>Edit Website Name</span>
                </button>
              </li>
              <li><a href="#returns" className="hover:text-white transition-colors">30-Day Free Returns</a></li>
              <li><a href="#shipping" className="hover:text-white transition-colors">Worldwide Shipping</a></li>
              <li><a href="#sizing" className="hover:text-white transition-colors">Size Guide & Fit</a></li>
            </ul>
          </div>

          {/* Col 4: Trust */}
          <div className="space-y-2">
            <h4 className="text-white font-bold uppercase tracking-wider text-[11px]">Authenticity</h4>
            <p className="text-[11px] text-neutral-500">
              All items are stamped with cryptographic RFID authenticity tags upon final inspection.
            </p>
            <div className="pt-2 flex items-center gap-2 text-emerald-400 text-[11px]">
              <ShieldCheck className="w-4 h-4" />
              <span>100% Genuine Guarantee</span>
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="mt-12 pt-6 border-t border-neutral-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-600">
          <p>© {new Date().getFullYear()} {brand.name} {brand.tagline}. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>Tokyo</span>
            <span>•</span>
            <span>New York</span>
            <span>•</span>
            <span>Seoul</span>
            <span>•</span>
            <span>Paris</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
