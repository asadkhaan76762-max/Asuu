import React from 'react';
import { X, Heart, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Product } from '../types';

interface WishlistModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
}

export const WishlistModal: React.FC<WishlistModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct
}) => {
  const { wishlist, toggleWishlist, addToCart } = useCart();

  if (!isOpen) return null;

  const handleMoveToBag = (product: Product) => {
    addToCart(product, product.sizes[0] || 'M', product.colors[0]?.name || 'Standard', 1);
    toggleWishlist(product);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/80 backdrop-blur-md animate-in fade-in">
      <div 
        className="relative w-full max-w-2xl bg-[#121316] border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-2.5">
            <Heart className="w-5 h-5 text-rose-500 fill-current" />
            <h3 className="font-bold text-white text-base uppercase tracking-wider font-display">
              Saved Wishlist ({wishlist.length})
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wishlist Items */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-4">
          {wishlist.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <div className="w-14 h-14 rounded-full bg-neutral-900 text-neutral-600 flex items-center justify-center mx-auto">
                <Heart className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-white uppercase tracking-wider">No Saved Grails</h4>
              <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                Tap the heart on any drop or sneaker to build your personal wishlist.
              </p>
            </div>
          ) : (
            wishlist.map((product) => (
              <div
                key={product.id}
                className="p-3.5 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center gap-4 group"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  onClick={() => {
                    onClose();
                    onSelectProduct(product);
                  }}
                  className="w-16 h-16 rounded-xl object-cover bg-neutral-800 shrink-0 cursor-pointer group-hover:scale-105 transition-transform"
                />

                <div className="flex-1 min-w-0">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                    {product.category}
                  </span>
                  <h4
                    onClick={() => {
                      onClose();
                      onSelectProduct(product);
                    }}
                    className="text-xs font-bold text-white truncate cursor-pointer hover:text-amber-400 transition-colors"
                  >
                    {product.name}
                  </h4>
                  <span className="text-xs font-bold text-neutral-300 font-display">
                    ${product.price}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleMoveToBag(product)}
                    className="px-3 py-2 bg-amber-400 hover:bg-amber-300 text-black text-xs font-bold uppercase rounded-xl transition-all flex items-center gap-1.5"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Move to Bag</span>
                  </button>
                  <button
                    onClick={() => toggleWishlist(product)}
                    className="p-2 text-neutral-500 hover:text-rose-400 transition-colors"
                    title="Remove"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {wishlist.length > 0 && (
          <div className="p-4 border-t border-neutral-800 bg-neutral-900/60 flex justify-end">
            <button
              onClick={onClose}
              className="px-5 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold uppercase rounded-xl transition-colors"
            >
              Continue Browsing
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
