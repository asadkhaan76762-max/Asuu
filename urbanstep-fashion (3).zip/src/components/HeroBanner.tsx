import React from 'react';
import { ArrowUpRight, Sparkles, ShieldCheck, Flame, Zap } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useBrand } from '../context/BrandContext';

interface HeroBannerProps {
  onExploreClick: () => void;
  onSneakersClick: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ onExploreClick, onSneakersClick }) => {
  const { isAuthenticated, openAuthModal, user } = useAuth();
  const { brand } = useBrand();

  return (
    <div className="relative overflow-hidden bg-neutral-950 border-b border-neutral-800">
      {/* Background glowing gradients */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-80 h-80 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Headlines & CTA */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black tracking-widest uppercase bg-amber-400 text-black shadow-[0_0_20px_rgba(251,191,36,0.4)]">
                <Flame className="w-3.5 h-3.5" />
                DROP 04 LIVE
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold tracking-wider uppercase bg-neutral-900 border border-neutral-800 text-neutral-300">
                LIMITED RUN // SHIBUYA STUDIO
              </span>
            </div>

            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-white uppercase tracking-tight leading-[0.95] font-display">
              URBAN LUXURY. <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-rose-400 to-cyan-400">
                FUTURE MOVEMENT.
              </span>
            </h1>

            <p className="text-neutral-400 text-sm sm:text-base max-w-xl leading-relaxed">
              Engineered footwear, modular technical outerwear, and high-density street silhouettes. 
              Designed in Tokyo for relentless urban exploration.
            </p>

            {/* Quick action buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onExploreClick}
                className="px-6 sm:px-8 py-4 bg-white hover:bg-neutral-200 text-black font-extrabold text-xs uppercase tracking-wider rounded-2xl transition-all shadow-xl flex items-center gap-2 font-display"
              >
                <span>Shop New Collection</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>

              <button
                onClick={onSneakersClick}
                className="px-6 py-4 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-white font-bold text-xs uppercase tracking-wider rounded-2xl transition-all"
              >
                Sneaker Drops
              </button>
            </div>

            {/* Sign up prompt card if not authenticated */}
            {!isAuthenticated ? (
              <div className="mt-8 p-4 rounded-2xl bg-neutral-900/80 border border-amber-400/30 backdrop-blur-md flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center shrink-0">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white uppercase">
                      New to {brand.name}? Get 600 Welcome Points
                    </h4>
                    <p className="text-[11px] text-neutral-400">
                      Sign up in 30 seconds for members-only release access & instant discounts.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openAuthModal('signup')}
                    className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-black text-xs font-extrabold uppercase rounded-xl transition-all font-display shrink-0"
                  >
                    Create Account
                  </button>
                  <button
                    onClick={() => openAuthModal('signin')}
                    className="px-3 py-2 text-neutral-400 hover:text-white text-xs font-bold uppercase transition-colors shrink-0"
                  >
                    Sign In
                  </button>
                </div>
              </div>
            ) : (
              <div className="mt-6 p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-cyan-400/20 text-cyan-400 flex items-center justify-center font-bold text-xs">
                    <Zap className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block">
                      VIP Status Active: {user?.name}
                    </span>
                    <span className="text-[11px] text-neutral-400">
                      You have <strong className="text-amber-400">{user?.memberPoints} UrbanPoints</strong> available. Code URBAN20 ready at checkout.
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Editorial Hero Visual Cards */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Main feature image */}
              <div className="relative aspect-[4/5] rounded-3xl overflow-hidden border border-neutral-800 shadow-2xl group">
                <img
                  src="https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1200&q=80"
                  alt="UrbanStep Kinetic Runner"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />

                {/* Card overlay info */}
                <div className="absolute bottom-5 left-5 right-5 p-4 rounded-2xl bg-black/60 backdrop-blur-md border border-neutral-800">
                  <div className="flex justify-between items-end">
                    <div>
                      <span className="text-[10px] font-mono text-amber-400 uppercase font-bold">
                        FEATURED RELEASE
                      </span>
                      <h3 className="text-lg font-black text-white uppercase font-display leading-tight">
                        KINETIC VORTEX 01
                      </h3>
                      <p className="text-xs text-neutral-400">Decoupled Sole • Carbon Fiber Shank</p>
                    </div>
                    <span className="text-xl font-black text-white font-display">$240</span>
                  </div>
                </div>
              </div>

              {/* Floating mini editorial tag */}
              <div className="absolute -top-3 -right-3 sm:-right-4 bg-[#16171a] border border-neutral-700 rounded-2xl p-3 shadow-2xl flex items-center gap-3 backdrop-blur-md">
                <div className="w-8 h-8 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center font-bold text-xs">
                  04
                </div>
                <div>
                  <div className="text-[10px] text-neutral-400 uppercase font-bold">Tokyo Runway</div>
                  <div className="text-xs font-bold text-white">Autumn / Winter Edition</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Highlights Bar */}
        <div className="mt-12 pt-8 border-t border-neutral-800/80 grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-bold text-white uppercase">Authenticity Guaranteed</div>
              <div className="text-[11px] text-neutral-500">Every piece individually verified</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-bold text-white uppercase">Member Drop Privileges</div>
              <div className="text-[11px] text-neutral-500">Sign up for early access</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Zap className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-bold text-white uppercase">Express Global Dispatch</div>
              <div className="text-[11px] text-neutral-500">Dispatched in 24 hours</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Flame className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <div className="font-bold text-white uppercase">Limited Production</div>
              <div className="text-[11px] text-neutral-500">Zero fast fashion waste</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
