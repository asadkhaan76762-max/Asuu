import React, { useState } from 'react';
import { X, CheckCircle, ShieldCheck, CreditCard, Truck, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useBrand } from '../context/BrandContext';
import { Order, ShippingAddress } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose }) => {
  const { user, openAuthModal } = useAuth();
  const { cart, total, discount, subtotal, shippingFee, placeOrder } = useCart();
  const { brand } = useBrand();

  const [paymentMethod, setPaymentMethod] = useState<'card' | 'applepay' | 'cod'>('card');
  const [recipientName, setRecipientName] = useState(user?.name || '');
  const [street, setStreet] = useState(user?.addresses?.[0]?.street || '104 Shibuya Crossing Ave');
  const [city, setCity] = useState(user?.addresses?.[0]?.city || 'Tokyo');
  const [state, setState] = useState(user?.addresses?.[0]?.state || 'Tokyo Prefecture');
  const [zip, setZip] = useState(user?.addresses?.[0]?.zip || '150-0043');
  const [country, setCountry] = useState(user?.addresses?.[0]?.country || 'Japan');
  const [cardNumber, setCardNumber] = useState('•••• •••• •••• 4242');
  const [cardExp, setCardExp] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('888');

  const [isProcessing, setIsProcessing] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  if (!isOpen) return null;

  const handleCompleteOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    const shippingAddress: ShippingAddress = {
      id: 'addr-checkout-' + Date.now(),
      name: recipientName || `${brand.name} Member`,
      street,
      city,
      state,
      zip,
      country,
      isDefault: true
    };

    setTimeout(async () => {
      const order = await placeOrder(shippingAddress);
      setCompletedOrder(order);
      setIsProcessing(false);
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-md animate-in fade-in">
      <div 
        className="relative w-full max-w-2xl bg-[#121316] border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="h-1.5 w-full bg-gradient-to-r from-amber-400 via-rose-500 to-cyan-400" />

        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white z-10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {completedOrder ? (
          <div className="p-8 sm:p-12 text-center space-y-5">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto ring-8 ring-emerald-500/10">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                PAYMENT CONFIRMED
              </span>
              <h3 className="text-3xl font-black text-white mt-3 font-display">
                DROP ORDER LOCKED IN
              </h3>
              <p className="text-xs text-neutral-400 mt-2">
                Order ID: <span className="text-white font-mono font-bold">{completedOrder.id}</span>
              </p>
            </div>

            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-4 text-left space-y-2 text-xs">
              <div className="flex justify-between text-neutral-400 pb-2 border-b border-neutral-800">
                <span>Tracking Number</span>
                <span className="font-mono text-amber-400 font-bold">{completedOrder.trackingNumber}</span>
              </div>
              <div className="flex justify-between text-neutral-400 pb-2 border-b border-neutral-800">
                <span>Shipping Destination</span>
                <span className="text-white text-right max-w-[250px] truncate">
                  {completedOrder.shippingAddress.street}, {completedOrder.shippingAddress.city}
                </span>
              </div>
              <div className="flex justify-between text-neutral-400 pt-1">
                <span>Total Paid</span>
                <span className="text-lg font-bold text-white">${completedOrder.totalAmount}</span>
              </div>
            </div>

            <div className="p-3 bg-amber-400/10 border border-amber-400/20 rounded-xl flex items-center justify-center gap-2 text-xs text-amber-300">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>+{Math.round(completedOrder.totalAmount)} UrbanPoints added to your loyalty balance!</span>
            </div>

            <button
              onClick={onClose}
              className="w-full bg-white hover:bg-neutral-200 text-black font-extrabold uppercase py-3.5 rounded-xl transition-all font-display text-sm"
            >
              Back to {brand.name} Collective
            </button>
          </div>
        ) : (
          <form onSubmit={handleCompleteOrder} className="p-6 sm:p-8 space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-bold tracking-widest uppercase bg-amber-400/10 text-amber-400 border border-amber-400/20 px-2.5 py-0.5 rounded-full">
                  SECURE VAULT CHECKOUT
                </span>
              </div>
              <h3 className="text-2xl font-black text-white uppercase font-display">
                Complete Your Order
              </h3>
              {!user && (
                <div className="mt-2 p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl flex items-center justify-between text-xs">
                  <span className="text-neutral-400">Ordering as Guest?</span>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      openAuthModal('signin');
                    }}
                    className="text-amber-400 hover:underline font-bold"
                  >
                    Sign In to earn +{Math.round(total)} PTS →
                  </button>
                </div>
              )}
            </div>

            {/* Shipping Address */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-neutral-300 uppercase tracking-wider">
                <Truck className="w-4 h-4 text-amber-400" />
                <span>1. Shipping Information</span>
              </div>

              <div>
                <input
                  type="text"
                  placeholder="Recipient Full Name"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Street Address"
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                  required
                />
                <input
                  type="text"
                  placeholder="City"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <input
                  type="text"
                  placeholder="State / Region"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500"
                />
                <input
                  type="text"
                  placeholder="ZIP / Postal"
                  value={zip}
                  onChange={(e) => setZip(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500"
                  required
                />
                <input
                  type="text"
                  placeholder="Country"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500"
                />
              </div>
            </div>

            {/* Payment Method */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-neutral-300 uppercase tracking-wider">
                <CreditCard className="w-4 h-4 text-amber-400" />
                <span>2. Payment Option</span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'card', label: 'Credit Card', icon: CreditCard },
                  { id: 'applepay', label: 'Apple / Google Pay', icon: Sparkles },
                  { id: 'cod', label: 'Express Delivery COD', icon: Truck },
                ].map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setPaymentMethod(m.id as any)}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      paymentMethod === m.id
                        ? 'border-amber-400 bg-amber-400/10 text-white font-bold'
                        : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <div className="text-[11px] font-semibold">{m.label}</div>
                  </button>
                ))}
              </div>

              {paymentMethod === 'card' && (
                <div className="p-4 bg-neutral-900 rounded-2xl border border-neutral-800 space-y-3">
                  <div>
                    <label className="text-[10px] text-neutral-400 uppercase font-semibold block mb-1">
                      Card Number
                    </label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs font-mono text-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-neutral-400 uppercase font-semibold block mb-1">
                        Expires
                      </label>
                      <input
                        type="text"
                        value={cardExp}
                        onChange={(e) => setCardExp(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs font-mono text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-neutral-400 uppercase font-semibold block mb-1">
                        CVC
                      </label>
                      <input
                        type="text"
                        value={cardCvc}
                        onChange={(e) => setCardCvc(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs font-mono text-white"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Cost breakdown */}
            <div className="p-4 bg-neutral-900 rounded-2xl border border-neutral-800 space-y-1.5 text-xs">
              <div className="flex justify-between text-neutral-400">
                <span>Subtotal ({cart.length} items)</span>
                <span>${subtotal}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>VIP / Promo Discount</span>
                  <span>-${discount}</span>
                </div>
              )}
              <div className="flex justify-between text-neutral-400">
                <span>Shipping</span>
                <span>{shippingFee === 0 ? 'FREE' : `$${shippingFee}`}</span>
              </div>
              <div className="flex justify-between text-white font-bold text-base pt-2 border-t border-neutral-800 font-display">
                <span>Total Due</span>
                <span>${total}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isProcessing}
              className="w-full bg-amber-400 hover:bg-amber-300 text-black font-extrabold uppercase py-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-400/20 disabled:opacity-50 font-display text-sm tracking-wide"
            >
              {isProcessing ? (
                <span>Authorizing Drop Payment...</span>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Confirm Order (${total})</span>
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
