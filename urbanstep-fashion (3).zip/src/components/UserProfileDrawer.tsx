import React, { useState } from 'react';
import { X, Award, Package, MapPin, Sparkles, LogOut, Plus, Check, Clock, ChevronRight, Phone, Edit3, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useBrand } from '../context/BrandContext';
import { User, ShippingAddress } from '../types';

interface UserProfileDrawerProps {
  onOpenDashboard?: () => void;
}

export const UserProfileDrawer: React.FC<UserProfileDrawerProps> = ({ onOpenDashboard }) => {
  const { user, signOut, isProfileDrawerOpen, setIsProfileDrawerOpen, updateProfile, addAddress, deleteAddress } = useAuth();
  const { orders } = useCart();
  const { brand, openBrandEditor } = useBrand();

  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'addresses' | 'style'>('overview');
  const [showAddAddress, setShowAddAddress] = useState(false);
  const [newStreet, setNewStreet] = useState('');
  const [newCity, setNewCity] = useState('');
  const [newState, setNewState] = useState('');
  const [newZip, setNewZip] = useState('');
  const [newCountry, setNewCountry] = useState('United States');

  if (!isProfileDrawerOpen || !user) return null;

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStreet || !newCity) return;

    addAddress({
      name: user.name,
      street: newStreet,
      city: newCity,
      state: newState,
      zip: newZip,
      country: newCountry,
      isDefault: (user.addresses || []).length === 0
    });

    setNewStreet('');
    setNewCity('');
    setNewState('');
    setNewZip('');
    setShowAddAddress(false);
  };

  const memberTierColors = {
    'Bronze': 'text-amber-600 bg-amber-600/10 border-amber-600/30',
    'Silver': 'text-slate-300 bg-slate-400/10 border-slate-400/30',
    'Gold': 'text-amber-400 bg-amber-400/10 border-amber-400/30',
    'VIP Elite': 'text-cyan-400 bg-cyan-400/10 border-cyan-400/30 shadow-[0_0_15px_rgba(6,182,212,0.2)]'
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#121316] border-l border-neutral-800 shadow-2xl flex flex-col">
          {/* Header */}
          <div className="p-6 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
            <div className="flex items-center gap-3">
              <div className="relative">
                {user.avatar ? (
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-amber-400"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-400 to-amber-600 text-black flex items-center justify-center font-bold text-lg">
                    {user.name.slice(0, 2).toUpperCase()}
                  </div>
                )}
                <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-[#121316]"></span>
              </div>
              <div>
                <h3 className="font-bold text-white text-base font-display">{user.name}</h3>
                <p className="text-xs text-neutral-400 truncate max-w-[190px]">{user.email}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase tracking-wider ${memberTierColors[user.memberTier] || memberTierColors['VIP Elite']}`}>
                    {user.memberTier}
                  </span>
                  <span className="text-[10px] text-neutral-500">{user.joinedDate}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setIsProfileDrawerOpen(false)}
              className="p-2 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation tabs */}
          <div className="grid grid-cols-4 border-b border-neutral-800 bg-neutral-900/40 text-xs">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-3 font-semibold transition-colors flex flex-col items-center gap-1 ${
                activeTab === 'overview' ? 'text-amber-400 border-b-2 border-amber-400' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>Overview</span>
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`py-3 font-semibold transition-colors flex flex-col items-center gap-1 relative ${
                activeTab === 'orders' ? 'text-amber-400 border-b-2 border-amber-400' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>Orders ({orders.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('addresses')}
              className={`py-3 font-semibold transition-colors flex flex-col items-center gap-1 ${
                activeTab === 'addresses' ? 'text-amber-400 border-b-2 border-amber-400' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <MapPin className="w-4 h-4" />
              <span>Addresses</span>
            </button>
            <button
              onClick={() => setActiveTab('style')}
              className={`py-3 font-semibold transition-colors flex flex-col items-center gap-1 ${
                activeTab === 'style' ? 'text-amber-400 border-b-2 border-amber-400' : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Style ID</span>
            </button>
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* OVERVIEW TAB */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Points Card */}
                <div className="relative p-5 rounded-2xl bg-gradient-to-br from-neutral-800 to-neutral-900 border border-neutral-700/60 shadow-xl overflow-hidden">
                  <div className="absolute right-3 top-3 opacity-10">
                    <Award className="w-24 h-24 text-amber-400" />
                  </div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs uppercase tracking-widest text-neutral-400 font-bold">
                      {brand.name} Rewards
                    </span>
                    <span className="text-[10px] font-mono bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded-full">
                      {(user.memberPoints || 0) >= 1000 ? 'MAX TIER' : 'LEVELING UP'}
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-black text-white font-display">
                      {user.memberPoints?.toLocaleString() || 600}
                    </span>
                    <span className="text-sm text-amber-400 font-bold">URBANPOINTS</span>
                  </div>
                  <p className="text-xs text-neutral-400 mt-2">
                    Redeemable for up to <strong className="text-white">${Math.floor((user.memberPoints || 600) / 50)} OFF</strong> on your next sneaker or outerwear order.
                  </p>
                  <div className="mt-4 pt-3 border-t border-neutral-700/50 flex items-center justify-between text-xs">
                    <span className="text-neutral-400">Next drop preview</span>
                    <span className="text-amber-400 font-bold flex items-center gap-1">
                      Priority Access Active <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>

                {/* Full Dashboard Shortcut */}
                {onOpenDashboard && (
                  <button
                    onClick={() => {
                      setIsProfileDrawerOpen(false);
                      onOpenDashboard();
                    }}
                    className="w-full py-3 px-4 bg-amber-400 hover:bg-amber-300 text-black font-extrabold uppercase rounded-2xl transition-all shadow-lg flex items-center justify-center gap-2 text-xs font-display"
                  >
                    <LayoutDashboard className="w-4 h-4" />
                    <span>Open Full VIP Dashboard</span>
                  </button>
                )}

                {/* VIP Perks */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-300 mb-3">
                    Active Member Perks
                  </h4>
                  <div className="space-y-2 text-xs">
                    <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-amber-400/10 text-amber-400 flex items-center justify-center shrink-0">
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-semibold text-white">15% Automatic VIP Discount</div>
                        <div className="text-[11px] text-neutral-500">Applied automatically or via coupon URBAN20</div>
                      </div>
                    </div>

                    <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-cyan-400/10 text-cyan-400 flex items-center justify-center shrink-0">
                        <Clock className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-semibold text-white">2-Hour Early Access</div>
                        <div className="text-[11px] text-neutral-500">Reserved sizing before public drops</div>
                      </div>
                    </div>

                    <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-emerald-400/10 text-emerald-400 flex items-center justify-center shrink-0">
                        <Package className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-semibold text-white">Complimentary Express Shipping</div>
                        <div className="text-[11px] text-neutral-500">On all footwear and limited apparel</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Member Details */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-300 mb-2">
                    Profile Data
                  </h4>
                  <div className="bg-neutral-900 p-4 rounded-xl border border-neutral-800 space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-neutral-800">
                      <span className="text-neutral-500">Full Name</span>
                      <span className="text-white font-medium">{user.name}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-neutral-800">
                      <span className="text-neutral-500">Email</span>
                      <span className="text-white font-medium">{user.email}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-neutral-800">
                      <span className="text-neutral-500">Style Vibe</span>
                      <span className="text-amber-400 font-bold">{user.preferredStyle}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-neutral-500">Phone</span>
                      <span className="text-white font-medium flex items-center gap-1">
                        <Phone className="w-3 h-3 text-neutral-500" />
                        {user.phone || '+1 (555) 382-9011'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ORDERS TAB */}
            {activeTab === 'orders' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                    Order History
                  </h4>
                  <span className="text-xs text-neutral-500">{orders.length} orders</span>
                </div>

                {orders.length === 0 ? (
                  <div className="text-center py-12 text-neutral-500 text-xs">
                    <Package className="w-10 h-10 mx-auto mb-2 opacity-30" />
                    <p>No orders yet. Add items to your bag to place your first drop order!</p>
                  </div>
                ) : (
                  orders.map((order) => (
                    <div
                      key={order.id}
                      className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl space-y-3"
                    >
                      <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                        <div>
                          <span className="font-mono text-xs font-bold text-white">{order.id}</span>
                          <span className="text-[10px] text-neutral-500 block">{order.date}</span>
                        </div>
                        <span
                          className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase ${
                            order.status === 'Delivered'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-amber-400/10 text-amber-400 border border-amber-400/20 animate-pulse'
                          }`}
                        >
                          {order.status}
                        </span>
                      </div>

                      {/* Items */}
                      <div className="space-y-2">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex items-center gap-3">
                            <img
                              src={item.product.image}
                              alt={item.product.name}
                              className="w-10 h-10 rounded-lg object-cover bg-neutral-800"
                            />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-semibold text-white truncate">{item.product.name}</p>
                              <p className="text-[10px] text-neutral-400">
                                Size: {item.selectedSize} • Qty: {item.quantity}
                              </p>
                            </div>
                            <span className="text-xs font-bold text-white">${item.product.price * item.quantity}</span>
                          </div>
                        ))}
                      </div>

                      {/* Footer */}
                      <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-xs">
                        <div className="text-[11px] text-neutral-400">
                          Tracking: <span className="font-mono text-neutral-300">{order.trackingNumber}</span>
                        </div>
                        <span className="font-bold text-white text-sm">${order.totalAmount}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* ADDRESSES TAB */}
            {activeTab === 'addresses' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-300">
                    Saved Delivery Addresses
                  </h4>
                  <button
                    onClick={() => setShowAddAddress(!showAddAddress)}
                    className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-bold"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add New</span>
                  </button>
                </div>

                {showAddAddress && (
                  <form onSubmit={handleSaveAddress} className="p-4 bg-neutral-900 border border-amber-400/40 rounded-2xl space-y-3">
                    <h5 className="text-xs font-bold text-white uppercase">New Shipping Address</h5>
                    <div>
                      <input
                        type="text"
                        placeholder="Street address / apartment"
                        value={newStreet}
                        onChange={(e) => setNewStreet(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder="City"
                        value={newCity}
                        onChange={(e) => setNewCity(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                        required
                      />
                      <input
                        type="text"
                        placeholder="State / Region"
                        value={newState}
                        onChange={(e) => setNewState(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder="Postal Code / Zip"
                        value={newZip}
                        onChange={(e) => setNewZip(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                      />
                      <input
                        type="text"
                        placeholder="Country"
                        value={newCountry}
                        onChange={(e) => setNewCountry(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                      />
                    </div>
                    <div className="flex gap-2 pt-1">
                      <button
                        type="submit"
                        className="flex-1 bg-amber-400 hover:bg-amber-300 text-black font-bold py-2 rounded-xl text-xs"
                      >
                        Save Address
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowAddAddress(false)}
                        className="px-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 py-2 rounded-xl text-xs"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                )}

                {(!user.addresses || user.addresses.length === 0) ? (
                  <div className="text-center py-8 text-neutral-500 text-xs">
                    <MapPin className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p>No addresses saved yet. Click "Add New" above.</p>
                  </div>
                ) : (
                  user.addresses.map((addr) => (
                    <div
                      key={addr.id}
                      className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl relative"
                    >
                      {addr.isDefault && (
                        <span className="text-[10px] font-bold bg-amber-400/10 text-amber-400 border border-amber-400/30 px-2 py-0.5 rounded-full absolute top-3 right-3 flex items-center gap-1">
                          <Check className="w-2.5 h-2.5" /> DEFAULT
                        </span>
                      )}
                      <p className="text-xs font-bold text-white">{addr.name}</p>
                      <p className="text-xs text-neutral-400 mt-1">{addr.street}</p>
                      <p className="text-xs text-neutral-400">
                        {addr.city}, {addr.state} {addr.zip}
                      </p>
                      <p className="text-xs text-neutral-400">{addr.country}</p>
                      <div className="mt-3 pt-2 border-t border-neutral-800/80 flex items-center justify-end">
                        <button
                          onClick={() => deleteAddress(addr.id)}
                          className="text-[11px] text-rose-400 hover:underline"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* STYLE TAB */}
            {activeTab === 'style' && (
              <div className="space-y-4">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1">
                    Your Curated Aesthetic
                  </h4>
                  <p className="text-xs text-neutral-500">
                    We tailor our drop recommendations based on your selected fashion aesthetic.
                  </p>
                </div>

                <div className="space-y-2">
                  {(['Streetwear', 'Techwear', 'Sneakerhead', 'Minimalist', 'Avant-Garde'] as const).map((style) => (
                    <button
                      key={style}
                      onClick={() => updateProfile({ preferredStyle: style })}
                      className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                        user.preferredStyle === style
                          ? 'border-amber-400 bg-amber-400/10 text-white font-bold'
                          : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Sparkles className={`w-4 h-4 ${user.preferredStyle === style ? 'text-amber-400' : 'text-neutral-600'}`} />
                        <span className="text-xs">{style}</span>
                      </div>
                      {user.preferredStyle === style && (
                        <span className="text-[10px] bg-amber-400 text-black px-2 py-0.5 rounded-full font-bold">
                          CURRENT
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Drawer Footer with Sign Out & Edit Store Name */}
          <div className="p-4 border-t border-neutral-800 bg-neutral-900/80 flex items-center justify-between">
            <button
              onClick={signOut}
              className="flex items-center gap-2 text-xs font-bold text-rose-400 hover:text-rose-300 transition-colors px-3 py-2 rounded-xl hover:bg-rose-500/10"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
            <button
              onClick={() => {
                setIsProfileDrawerOpen(false);
                openBrandEditor();
              }}
              className="flex items-center gap-1.5 text-xs font-semibold text-neutral-400 hover:text-amber-400 transition-colors px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700"
            >
              <Edit3 className="w-3.5 h-3.5 text-amber-400" />
              <span>Edit Store Name</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
