import React, { useState } from 'react';
import { X, Lock, Mail, User as UserIcon, Sparkles, CheckCircle2, Eye, EyeOff, ShieldCheck, ArrowRight, Zap } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useBrand } from '../context/BrandContext';
import { User } from '../types';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authMode,
    switchAuthMode,
    signIn,
    signUp,
    signInWithGoogle,
    quickDemoLogin
  } = useAuth();
  const { brand } = useBrand();

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [preferredStyle, setPreferredStyle] = useState<User['preferredStyle']>('Streetwear');
  const [rememberMe, setRememberMe] = useState(true);
  const [agreedToTerms, setAgreedToTerms] = useState(true);
  const [statusMessage, setStatusMessage] = useState<{ type: 'error' | 'success' | null; text: string }>({
    type: null,
    text: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  if (!isAuthModalOpen) return null;

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage({ type: null, text: '' });

    if (!email) {
      setStatusMessage({ type: 'error', text: 'Please enter your email address.' });
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = signIn(email, password);
      setIsSubmitting(false);
      if (res.success) {
        setStatusMessage({ type: 'success', text: res.message });
      } else {
        setStatusMessage({ type: 'error', text: res.message });
      }
    }, 400);
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage({ type: null, text: '' });

    if (!name.trim()) {
      setStatusMessage({ type: 'error', text: 'Please enter your full name.' });
      return;
    }

    if (!email.trim() || !email.includes('@')) {
      setStatusMessage({ type: 'error', text: 'Please enter a valid email address.' });
      return;
    }

    if (!password || password.length < 6) {
      setStatusMessage({ type: 'error', text: 'Password should be at least 6 characters.' });
      return;
    }

    if (!agreedToTerms) {
      setStatusMessage({ type: 'error', text: `Please accept the ${brand.name} member terms.` });
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = signUp({
        name,
        email,
        password,
        preferredStyle,
        subscribeNewsletter: true
      });
      setIsSubmitting(false);
      if (res.success) {
        setStatusMessage({ type: 'success', text: res.message });
      }
    }, 500);
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setStatusMessage({ type: 'error', text: 'Please enter your email address to reset password.' });
      return;
    }
    setResetSent(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-xl bg-[#121316] border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top gradient aesthetic line */}
        <div className="h-1.5 w-full bg-gradient-to-r from-amber-400 via-rose-500 to-cyan-400" />

        {/* Close Button */}
        <button
          onClick={closeAuthModal}
          className="absolute top-5 right-5 p-2 rounded-full bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-all z-10"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="px-6 sm:px-8 pt-8 pb-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-widest uppercase bg-amber-400/10 text-amber-400 border border-amber-400/20">
              {brand.name.toUpperCase()} VIP
            </span>
            <span className="text-xs text-neutral-400">Exclusive Drop Access</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight font-display">
            {authMode === 'signup' && 'Create Your Member Account'}
            {authMode === 'signin' && `Welcome Back to ${brand.name}`}
            {authMode === 'forgot-password' && 'Reset Member Access'}
          </h2>

          <p className="text-sm text-neutral-400 mt-1">
            {authMode === 'signup' && 'Sign up to unlock 600 Welcome Points, reserved sizing on limited drops & free priority delivery.'}
            {authMode === 'signin' && 'Sign in to access your saved wishlist, order tracking, and VIP tier benefits.'}
            {authMode === 'forgot-password' && 'Enter your registered email and we will send you instant recovery instructions.'}
          </p>

          {/* Mode Switcher Tabs */}
          {authMode !== 'forgot-password' && (
            <div className="grid grid-cols-2 p-1 bg-neutral-900 border border-neutral-800 rounded-2xl mt-5">
              <button
                type="button"
                onClick={() => {
                  switchAuthMode('signin');
                  setStatusMessage({ type: null, text: '' });
                }}
                className={`py-2.5 text-xs font-bold uppercase tracking-wider rounded-xl transition-all ${
                  authMode === 'signin'
                    ? 'bg-neutral-800 text-white shadow-md'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  switchAuthMode('signup');
                  setStatusMessage({ type: null, text: '' });
                }}
                className={`py-2.5 text-xs font-bold uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  authMode === 'signup'
                    ? 'bg-amber-400 text-black shadow-md font-extrabold'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <span>Sign Up</span>
                <span className="text-[10px] bg-black/20 px-1.5 py-0.5 rounded-full">+600 PTS</span>
              </button>
            </div>
          )}

          {/* Firebase Google Sign-In */}
          {authMode !== 'forgot-password' && (
            <div className="pt-4">
              <button
                type="button"
                onClick={async () => {
                  setIsSubmitting(true);
                  const res = await signInWithGoogle();
                  setIsSubmitting(false);
                  if (res.success) {
                    setStatusMessage({ type: 'success', text: res.message });
                  } else {
                    setStatusMessage({ type: 'error', text: res.message });
                  }
                }}
                disabled={isSubmitting}
                className="w-full py-3 px-4 bg-neutral-900 hover:bg-neutral-850 border border-neutral-700/80 rounded-xl text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2.5 transition-all shadow-md group hover:border-neutral-600"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Continue with Google</span>
              </button>

              <div className="flex items-center gap-3 my-3">
                <div className="flex-1 h-px bg-neutral-800" />
                <span className="text-[10px] text-neutral-500 uppercase font-mono tracking-wider">or with email</span>
                <div className="flex-1 h-px bg-neutral-800" />
              </div>
            </div>
          )}
        </div>

        {/* Status Notification */}
        {statusMessage.text && (
          <div className="px-6 sm:px-8">
            <div
              className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                statusMessage.type === 'error'
                  ? 'bg-rose-500/10 border border-rose-500/30 text-rose-300'
                  : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
              }`}
            >
              {statusMessage.type === 'error' ? (
                <ShieldCheck className="w-4 h-4 text-rose-400 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              )}
              <span>{statusMessage.text}</span>
            </div>
          </div>
        )}

        {/* SIGN IN FORM */}
        {authMode === 'signin' && (
          <form onSubmit={handleSignIn} className="px-6 sm:px-8 py-4 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. asadkhaan76762@gmail.com"
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 transition-colors"
                  required
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => switchAuthMode('forgot-password')}
                  className="text-xs text-amber-400 hover:underline"
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-10 pr-10 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between py-1">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-neutral-400">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-neutral-700 bg-neutral-800 text-amber-400 focus:ring-0 w-4 h-4 accent-amber-400"
                />
                <span>Remember me on this browser</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-white hover:bg-neutral-200 text-black font-bold uppercase tracking-wider py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg disabled:opacity-50 font-display"
            >
              {isSubmitting ? (
                <span>Authenticating...</span>
              ) : (
                <>
                  <span>Sign In to {brand.name}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            {/* Quick 1-click Demo Logins */}
            <div className="pt-4 border-t border-neutral-800/80">
              <div className="flex items-center gap-2 mb-2.5">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400">
                  Quick 1-Click Access
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => quickDemoLogin('asad')}
                  className="p-2.5 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-xl text-left transition-all group"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center text-xs font-bold">
                      AK
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-white group-hover:text-amber-400 transition-colors">
                        Asad Khan (VIP Elite)
                      </div>
                      <div className="text-[10px] text-neutral-500 truncate max-w-[170px]">
                        asadkhaan76762@gmail.com
                      </div>
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => quickDemoLogin('fashionista')}
                  className="p-2.5 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-xl text-left transition-all group"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center text-xs font-bold">
                      ER
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-white group-hover:text-rose-400 transition-colors">
                        Elena Rostova (Gold)
                      </div>
                      <div className="text-[10px] text-neutral-500">
                        Techwear Curator • NY
                      </div>
                    </div>
                  </div>
                </button>
              </div>
            </div>
          </form>
        )}

        {/* SIGN UP FORM */}
        {authMode === 'signup' && (
          <form onSubmit={handleSignUp} className="px-6 sm:px-8 py-4 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                  Full Name
                </label>
                <div className="relative">
                  <UserIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Asad Khan"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 transition-colors"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@domain.com"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 transition-colors"
                    required
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                Create Secure Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-10 pr-10 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 transition-colors"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Preferred Style Personality */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-semibold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Your Fashion Identity (+100 PTS Bonus)</span>
                </label>
                <span className="text-[10px] text-neutral-500">Customizes drops</span>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                {(['Streetwear', 'Techwear', 'Sneakerhead', 'Minimalist', 'Avant-Garde'] as const).map((style) => (
                  <button
                    key={style}
                    type="button"
                    onClick={() => setPreferredStyle(style)}
                    className={`py-2 px-1 text-[11px] font-medium rounded-xl border text-center transition-all ${
                      preferredStyle === style
                        ? 'border-amber-400 bg-amber-400/10 text-amber-300 font-bold'
                        : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {style}
                  </button>
                ))}
              </div>
            </div>

            {/* Terms and VIP perks */}
            <div className="space-y-2 pt-1 text-xs text-neutral-400">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={agreedToTerms}
                  onChange={(e) => setAgreedToTerms(e.target.checked)}
                  className="mt-0.5 rounded border-neutral-700 bg-neutral-800 text-amber-400 focus:ring-0 w-4 h-4 accent-amber-400"
                />
                <span>
                  I agree to the <span className="text-neutral-200 underline">{brand.name} Member Terms</span> and consent to receive secret drops & member perks.
                </span>
              </label>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold uppercase tracking-wider py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-400/20 disabled:opacity-50 font-display"
            >
              {isSubmitting ? (
                <span>Generating Your Membership...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Create Account & Claim 600 PTS</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* FORGOT PASSWORD FORM */}
        {authMode === 'forgot-password' && (
          <div className="px-6 sm:px-8 py-6 space-y-4">
            {resetSent ? (
              <div className="text-center py-6 space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-white">Reset Link Dispatched</h3>
                <p className="text-xs text-neutral-400 max-w-sm mx-auto">
                  We sent instructions to <strong className="text-neutral-200">{email}</strong>. Check your inbox and spam folder.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setResetSent(false);
                    switchAuthMode('signin');
                  }}
                  className="mt-4 px-6 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-bold uppercase rounded-xl"
                >
                  Return to Sign In
                </button>
              </div>
            ) : (
              <form onSubmit={handleResetPassword} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                    Account Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. asadkhaan76762@gmail.com"
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-white hover:bg-neutral-200 text-black font-bold uppercase tracking-wider py-3.5 rounded-xl transition-all"
                >
                  Send Recovery Link
                </button>

                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => switchAuthMode('signin')}
                    className="text-xs text-neutral-400 hover:text-white"
                  >
                    ← Back to Sign In
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* Modal Footer note */}
        <div className="px-6 sm:px-8 py-4 bg-neutral-950/60 border-t border-neutral-800/80 text-center">
          <p className="text-[11px] text-neutral-500">
            Protected by {brand.name} 256-bit encryption. Need instant assistance? Contact concierge@{brand.name.toLowerCase().replace(/\s+/g, '')}.com
          </p>
        </div>
      </div>
    </div>
  );
};
