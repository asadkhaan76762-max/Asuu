import React, { useState } from 'react';
import { ShoppingBag, Heart, Search, User as UserIcon, Menu, X, Sparkles, ChevronDown, Edit3, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useBrand } from '../context/BrandContext';
import { RunwayAudioPlayer } from './RunwayAudioPlayer';

interface NavbarProps {
  onSearchChange: (query: string) => void;
  searchQuery: string;
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  onOpenWishlistModal: () => void;
  onOpenDashboard: () => void;
  isDashboardActive?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  onSearchChange,
  searchQuery,
  selectedCategory,
  onSelectCategory,
  onOpenWishlistModal,
  onOpenDashboard,
  isDashboardActive = false
}) => {
  const { user, isAuthenticated, openAuthModal, setIsProfileDrawerOpen } = useAuth();
  const { cartCount, wishlist, setIsCartOpen } = useCart();
  const { brand, openBrandEditor } = useBrand();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);

  const navCategories = [
    'All Drops',
    'Sneakers',
    'Outerwear',
    'Hoodies & Tops',
    'Pants',
    'Accessories'
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#0c0d0e]/90 backdrop-blur-xl border-b border-neutral-800/80">
      {/* Top micro-bar ticker */}
      <div className="bg-gradient-to-r from-neutral-900 via-neutral-800 to-neutral-900 border-b border-neutral-800/60 px-4 py-1.5 text-[11px] text-neutral-300">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping"></span>
            <span className="font-bold tracking-widest text-amber-400 uppercase text-[10px]">
              DROP 04 LIVE NOW
            </span>
            <span className="hidden sm:inline text-neutral-400">|</span>
            <span className="hidden sm:inline text-neutral-300">
              Complimentary Worldwide Shipping on orders over $150
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={openBrandEditor}
              className="text-neutral-400 hover:text-amber-400 flex items-center gap-1 font-semibold text-[10px] uppercase tracking-wider bg-neutral-800/80 hover:bg-neutral-800 px-2 py-0.5 rounded-md transition-colors"
              title="Change website and brand name"
            >
              <Edit3 className="w-3 h-3 text-amber-400" />
              <span>Edit Store Name</span>
            </button>

            {!isAuthenticated ? (
              <button
                onClick={() => openAuthModal('signup')}
                className="text-amber-400 hover:text-amber-300 flex items-center gap-1 font-bold text-[10px] uppercase tracking-wider"
              >
                <Sparkles className="w-3 h-3" />
                <span>Join VIP Club for +600 PTS</span>
              </button>
            ) : (
              <span className="text-[10px] text-neutral-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                <span>VIP Member: <strong className="text-white">{user?.name}</strong></span>
                <span className="text-amber-400 font-bold">({user?.memberPoints} PTS)</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          {/* Brand Logo */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <button
                onClick={() => onSelectCategory('All Drops')}
                className="text-left group flex items-center gap-2.5"
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black font-display text-lg tracking-tighter shadow-[0_0_20px_rgba(251,191,36,0.3)]">
                  {brand.monogram}
                </div>
                <div>
                  <span className="text-lg sm:text-xl font-black tracking-tight text-white font-display block leading-none uppercase">
                    {brand.name}
                  </span>
                  <span className="text-[9px] uppercase tracking-[0.25em] text-neutral-400 font-bold">
                    {brand.tagline}
                  </span>
                </div>
              </button>

              <button
                onClick={openBrandEditor}
                className="p-1 rounded-md text-neutral-600 hover:text-amber-400 hover:bg-neutral-800 transition-colors"
                title="Edit Website Name"
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Desktop Navigation links */}
            <nav className="hidden lg:flex items-center gap-1 ml-4">
              {navCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => onSelectCategory(cat)}
                  className={`px-3 py-1.5 text-xs uppercase tracking-wider font-semibold rounded-lg transition-all ${
                    !isDashboardActive && selectedCategory === cat
                      ? 'text-white bg-neutral-800'
                      : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                  }`}
                >
                  {cat}
                </button>
              ))}

              <button
                onClick={onOpenDashboard}
                className={`px-3 py-1.5 text-xs uppercase tracking-wider font-bold rounded-lg transition-all flex items-center gap-1.5 ml-1 ${
                  isDashboardActive
                    ? 'bg-amber-400 text-black shadow-[0_0_15px_rgba(251,191,36,0.4)]'
                    : 'text-amber-300 hover:text-white hover:bg-amber-400/15 border border-amber-400/30'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                <span>Dashboard</span>
              </button>
            </nav>
          </div>

          {/* Right actions: Audio runway player, Search, Wishlist, Bag, Auth */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Runway audio music player ("singing / soundtrack") */}
            <RunwayAudioPlayer />

            {/* Search Input toggle/field */}
            <div className="relative">
              {isSearchExpanded ? (
                <div className="flex items-center bg-neutral-900 border border-amber-400/50 rounded-full px-3 py-1.5 w-48 sm:w-64 transition-all">
                  <Search className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => onSearchChange(e.target.value)}
                    placeholder="Search drops, sneakers..."
                    className="w-full bg-transparent px-2 text-xs text-white placeholder-neutral-500 focus:outline-none"
                    autoFocus
                  />
                  <button
                    onClick={() => {
                      setIsSearchExpanded(false);
                      onSearchChange('');
                    }}
                    className="text-neutral-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setIsSearchExpanded(true)}
                  className="p-2 sm:p-2.5 rounded-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors"
                  title="Search collections"
                >
                  <Search className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Wishlist button */}
            <button
              onClick={onOpenWishlistModal}
              className="relative p-2 sm:p-2.5 rounded-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors"
              title="View Wishlist"
            >
              <Heart className="w-4 h-4" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Bag button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 sm:p-2.5 rounded-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors"
              title="Shopping Bag"
            >
              <ShoppingBag className="w-4 h-4" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-400 text-black text-[10px] font-extrabold flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            {/* USER AUTH BUTTONS (THE CORE USER REQUEST) */}
            <div className="hidden sm:flex items-center gap-2 pl-1 border-l border-neutral-800">
              {isAuthenticated && user ? (
                <button
                  onClick={() => setIsProfileDrawerOpen(true)}
                  className="flex items-center gap-2 p-1.5 pr-3 rounded-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 transition-all group"
                >
                  {user.avatar ? (
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-7 h-7 rounded-full object-cover border border-amber-400"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-amber-400 text-black flex items-center justify-center font-bold text-xs">
                      {user.name.slice(0, 2).toUpperCase()}
                    </div>
                  )}
                  <div className="text-left">
                    <span className="text-xs font-bold text-white block leading-tight group-hover:text-amber-400 transition-colors">
                      {user.name.split(' ')[0]}
                    </span>
                    <span className="text-[10px] text-amber-400 font-mono leading-none block">
                      {user.memberTier}
                    </span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-neutral-500 group-hover:text-white transition-colors" />
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openAuthModal('signin')}
                    className="px-3.5 py-2 text-xs font-bold uppercase tracking-wider text-neutral-300 hover:text-white hover:bg-neutral-900 rounded-xl transition-all"
                  >
                    Sign In
                  </button>

                  <button
                    onClick={() => openAuthModal('signup')}
                    className="px-4 py-2 text-xs font-extrabold uppercase tracking-wider bg-amber-400 hover:bg-amber-300 text-black rounded-xl transition-all shadow-[0_0_15px_rgba(251,191,36,0.3)] flex items-center gap-1.5"
                  >
                    <UserIcon className="w-3.5 h-3.5" />
                    <span>Sign Up</span>
                  </button>
                </div>
              )}
            </div>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-neutral-800 bg-neutral-950 px-4 pt-4 pb-6 space-y-4 animate-in slide-in-from-top duration-200">
          {/* Mobile Auth actions */}
          <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
            {isAuthenticated && user ? (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-amber-400 text-black flex items-center justify-center font-bold text-sm">
                    {user.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">{user.name}</h4>
                    <p className="text-[10px] text-amber-400 font-mono">{user.memberTier} • {user.memberPoints} PTS</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    setIsProfileDrawerOpen(true);
                  }}
                  className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold"
                >
                  Manage
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    openAuthModal('signin');
                  }}
                  className="w-full py-2.5 text-center text-xs font-bold uppercase rounded-xl bg-neutral-800 text-white"
                >
                  Sign In
                </button>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    openAuthModal('signup');
                  }}
                  className="w-full py-2.5 text-center text-xs font-extrabold uppercase rounded-xl bg-amber-400 text-black"
                >
                  Sign Up (+600 PTS)
                </button>
              </div>
            )}
          </div>

          {/* Mobile Dashboard Button */}
          <button
            onClick={() => {
              setIsMobileMenuOpen(false);
              onOpenDashboard();
            }}
            className="w-full py-3 px-4 bg-amber-400 text-black rounded-xl font-bold uppercase text-xs flex items-center justify-center gap-2 shadow-lg"
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Open VIP Command Dashboard</span>
          </button>

          {/* Categories */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500 px-2 block">
              Categories
            </span>
            {navCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  onSelectCategory(cat);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider ${
                  selectedCategory === cat ? 'bg-amber-400 text-black font-bold' : 'text-neutral-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};
