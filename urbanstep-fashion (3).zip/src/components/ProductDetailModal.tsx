import React, { useState } from 'react';
import { X, Star, Heart, Check, ShoppingBag, ShieldCheck, RefreshCw } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Product } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ product, onClose }) => {
  const { addToCart, toggleWishlist, isInWishlist } = useCart();

  const [selectedImage, setSelectedImage] = useState<string>(product?.image || '');
  const [selectedSize, setSelectedSize] = useState<string>(product?.sizes[0] || '');
  const [selectedColor, setSelectedColor] = useState<string>(product?.colors[0]?.name || '');
  const [isAddedFeedback, setIsAddedFeedback] = useState(false);

  // Sync state when product changes
  React.useEffect(() => {
    if (product) {
      setSelectedImage(product.image);
      setSelectedSize(product.sizes[0] || '');
      setSelectedColor(product.colors[0]?.name || '');
    }
  }, [product]);

  if (!product) return null;

  const handleAddToCart = () => {
    addToCart(product, selectedSize, selectedColor, 1);
    setIsAddedFeedback(true);
    setTimeout(() => {
      setIsAddedFeedback(false);
    }, 1500);
  };

  const isWishlisted = isInWishlist(product.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/80 backdrop-blur-md animate-in fade-in">
      <div 
        className="relative w-full max-w-4xl bg-[#121316] border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-neutral-900/80 hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors z-20"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Images preview */}
          <div className="p-6 bg-neutral-950 flex flex-col justify-between">
            <div className="aspect-square w-full rounded-2xl overflow-hidden bg-neutral-900 relative">
              <img
                src={selectedImage || product.image}
                alt={product.name}
                className="w-full h-full object-cover transition-all duration-300"
              />
              {product.tag && (
                <span className="absolute top-3 left-3 bg-neutral-900/90 text-amber-400 font-bold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-full border border-neutral-700 backdrop-blur-md">
                  {product.tag}
                </span>
              )}
            </div>

            {/* Gallery Thumbnails */}
            {product.gallery && product.gallery.length > 1 && (
              <div className="flex gap-2 mt-4 overflow-x-auto pb-1">
                {product.gallery.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(img)}
                    className={`w-16 h-16 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                      selectedImage === img ? 'border-amber-400 scale-105' : 'border-neutral-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="Thumb" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div>
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <span className="text-[11px] font-bold uppercase tracking-widest text-amber-400">
                  {product.category}
                </span>
                <div className="flex items-center gap-1 text-xs text-amber-400">
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span className="font-bold">{product.rating}</span>
                  <span className="text-neutral-500">({product.reviewsCount})</span>
                </div>
              </div>

              <h2 className="text-2xl font-black text-white uppercase tracking-tight font-display">
                {product.name}
              </h2>
              <p className="text-xs text-neutral-400 mt-1">{product.subtitle}</p>

              <div className="flex items-baseline gap-3 mt-3">
                <span className="text-2xl font-black text-white font-display">${product.price}</span>
                {product.originalPrice && (
                  <span className="text-sm text-neutral-500 line-through">
                    ${product.originalPrice}
                  </span>
                )}
                {product.originalPrice && (
                  <span className="text-[10px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full border border-rose-500/20">
                    SAVE ${product.originalPrice - product.price}
                  </span>
                )}
              </div>

              <p className="text-xs text-neutral-300 mt-4 leading-relaxed">
                {product.description}
              </p>

              {/* Color Selection */}
              <div className="mt-5">
                <label className="text-xs font-semibold uppercase tracking-wider text-neutral-400 block mb-2">
                  Color: <span className="text-white">{selectedColor}</span>
                </label>
                <div className="flex items-center gap-2">
                  {product.colors.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => setSelectedColor(c.name)}
                      className={`w-7 h-7 rounded-full border-2 flex items-center justify-center transition-all ${
                        selectedColor === c.name
                          ? 'border-amber-400 scale-110 shadow-[0_0_10px_rgba(251,191,36,0.5)]'
                          : 'border-transparent hover:scale-105'
                      }`}
                      style={{ backgroundColor: c.hex }}
                      title={c.name}
                    >
                      {selectedColor === c.name && (
                        <Check className={`w-3.5 h-3.5 ${c.hex === '#e8e8e8' || c.hex === '#e3dfd7' || c.hex === '#b4f000' ? 'text-black' : 'text-white'}`} />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selection */}
              <div className="mt-5">
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                    Select Size
                  </label>
                  <span className="text-[10px] text-amber-400 uppercase font-mono">True to Fit</span>
                </div>
                <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                  {product.sizes.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSelectedSize(s)}
                      className={`py-2 px-1 text-xs font-bold rounded-xl border text-center transition-all ${
                        selectedSize === s
                          ? 'border-amber-400 bg-amber-400/10 text-amber-300'
                          : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white hover:border-neutral-700'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Technical features list */}
              {product.details && product.details.length > 0 && (
                <div className="mt-5 pt-4 border-t border-neutral-800 space-y-1.5">
                  <h4 className="text-[10px] font-bold uppercase tracking-wider text-neutral-500">
                    Product Specification
                  </h4>
                  {product.details.map((d, i) => (
                    <div key={i} className="text-[11px] text-neutral-400 flex items-start gap-2">
                      <span className="text-amber-400 font-bold">•</span>
                      <span>{d}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-neutral-800 flex items-center gap-3">
              <button
                onClick={handleAddToCart}
                className="flex-1 bg-amber-400 hover:bg-amber-300 text-black font-extrabold uppercase py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-400/20 font-display text-sm tracking-wide"
              >
                {isAddedFeedback ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Added to Bag!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>Add to Bag • ${product.price}</span>
                  </>
                )}
              </button>

              <button
                onClick={() => toggleWishlist(product)}
                className={`p-3.5 rounded-xl border transition-all ${
                  isWishlisted
                    ? 'border-rose-500 bg-rose-500/10 text-rose-400'
                    : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white'
                }`}
                title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-2 gap-2 text-[10px] text-neutral-500 pt-1">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>100% Verified Authentic Drop</span>
              </div>
              <div className="flex items-center gap-1.5">
                <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
                <span>Complimentary 30-Day Returns</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
