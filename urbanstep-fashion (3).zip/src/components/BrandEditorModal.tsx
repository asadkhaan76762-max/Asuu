import React, { useState, useEffect } from 'react';
import { X, Edit3, Sparkles, Check, RotateCcw, Palette, Type, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useBrand, BRAND_PRESETS } from '../context/BrandContext';
import { BrandConfig } from '../types';

export const BrandEditorModal: React.FC = () => {
  const { brand, isBrandEditorOpen, closeBrandEditor, updateBrand, resetBrand, applyPreset } = useBrand();

  const [name, setName] = useState(brand.name);
  const [tagline, setTagline] = useState(brand.tagline);
  const [monogram, setMonogram] = useState(brand.monogram);
  const [accentTheme, setAccentTheme] = useState<BrandConfig['accentTheme']>(brand.accentTheme);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    if (isBrandEditorOpen) {
      setName(brand.name);
      setTagline(brand.tagline);
      setMonogram(brand.monogram);
      setAccentTheme(brand.accentTheme);
      setSavedSuccess(false);
    }
  }, [isBrandEditorOpen, brand]);

  if (!isBrandEditorOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    updateBrand({
      name: name.trim(),
      tagline: tagline.trim() || 'Fashion Collective',
      monogram: monogram.trim().toUpperCase() || name.slice(0, 2).toUpperCase(),
      accentTheme
    });

    setSavedSuccess(true);
    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }

    setTimeout(() => {
      closeBrandEditor();
    }, 800);
  };

  const handleSelectPreset = (preset: typeof BRAND_PRESETS[0]) => {
    setName(preset.config.name);
    setTagline(preset.config.tagline);
    setMonogram(preset.config.monogram);
    setAccentTheme(preset.config.accentTheme);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-md animate-in fade-in">
      <div 
        className="relative w-full max-w-xl bg-[#121316] border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="h-1.5 w-full bg-gradient-to-r from-amber-400 via-rose-500 to-cyan-400" />

        {/* Close Button */}
        <button
          onClick={closeBrandEditor}
          className="absolute top-5 right-5 p-2 rounded-full bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-all z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="p-6 sm:p-8 pb-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-widest uppercase bg-amber-400/10 text-amber-400 border border-amber-400/20 flex items-center gap-1">
              <Edit3 className="w-3 h-3" />
              <span>CUSTOMIZE WEBSITE IDENTITY</span>
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight font-display">
            Edit Website & Brand Name
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            Rename the store, customize the logo monogram, and update brand styling across all headers, pages, and checkout receipts.
          </p>
        </div>

        {/* Live Preview Box */}
        <div className="px-6 sm:px-8 py-2">
          <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black font-display text-lg tracking-tighter shadow-lg">
                {monogram || name.slice(0, 2).toUpperCase()}
              </div>
              <div>
                <span className="text-lg font-black tracking-tight text-white font-display block leading-none">
                  {name || 'BRAND NAME'}
                </span>
                <span className="text-[10px] uppercase tracking-[0.2em] text-neutral-400 font-bold mt-1 block">
                  {tagline || 'Fashion Collective'}
                </span>
              </div>
            </div>
            <span className="text-[10px] font-mono bg-neutral-800 text-amber-400 px-2 py-1 rounded-full uppercase">
              LIVE PREVIEW
            </span>
          </div>
        </div>

        {/* Presets Bar */}
        <div className="px-6 sm:px-8 pt-4">
          <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block mb-2">
            Quick 1-Click Name Presets
          </label>
          <div className="flex flex-wrap gap-1.5">
            {BRAND_PRESETS.map((p) => (
              <button
                key={p.label}
                type="button"
                onClick={() => handleSelectPreset(p)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                  name.toLowerCase() === p.config.name.toLowerCase()
                    ? 'border-amber-400 bg-amber-400/10 text-amber-300 font-bold'
                    : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Form Fields */}
        <form onSubmit={handleSave} className="p-6 sm:p-8 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Type className="w-3.5 h-3.5 text-amber-400" />
              <span>Website / Brand Name</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                // auto-suggest monogram
                const words = e.target.value.trim().split(/\s+/);
                if (words.length >= 2) {
                  setMonogram((words[0][0] + words[1][0]).toUpperCase());
                } else if (words[0].length >= 2) {
                  setMonogram(words[0].slice(0, 2).toUpperCase());
                }
              }}
              placeholder="e.g. Khaan Step, UrbanStep, Tokyo Rogue..."
              className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 font-display font-bold tracking-wide"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                Tagline / Sub-heading
              </label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                placeholder="e.g. Luxury Streetwear Collective"
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                Logo Monogram (2 letters)
              </label>
              <input
                type="text"
                maxLength={3}
                value={monogram}
                onChange={(e) => setMonogram(e.target.value.toUpperCase())}
                placeholder="e.g. US, KS"
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white uppercase font-mono font-bold focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* Color theme selection */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-amber-400" />
              <span>Brand Accent Theme</span>
            </label>
            <div className="grid grid-cols-5 gap-2">
              {[
                { id: 'amber', label: 'Gold Amber', color: '#fbbf24' },
                { id: 'cyan', label: 'Cyber Cyan', color: '#06b6d4' },
                { id: 'rose', label: 'Tokyo Rose', color: '#f43f5e' },
                { id: 'emerald', label: 'Jade Acid', color: '#10b981' },
                { id: 'violet', label: 'Ultra Violet', color: '#8b5cf6' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setAccentTheme(t.id as any)}
                  className={`p-2 rounded-xl border text-center transition-all ${
                    accentTheme === t.id
                      ? 'border-white bg-neutral-800 text-white font-bold'
                      : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white'
                  }`}
                >
                  <div
                    className="w-4 h-4 rounded-full mx-auto mb-1 border border-black/40"
                    style={{ backgroundColor: t.color }}
                  />
                  <div className="text-[10px] truncate">{t.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 flex gap-3">
            <button
              type="submit"
              className="flex-1 bg-amber-400 hover:bg-amber-300 text-black font-extrabold uppercase py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-400/20 font-display text-xs"
            >
              {savedSuccess ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Name Updated Across Website!</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Apply New Website Name</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => {
                resetBrand();
                setName('UrbanStep');
                setTagline('Fashion Collective');
                setMonogram('US');
              }}
              className="p-3 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-400 hover:text-white rounded-xl transition-colors"
              title="Reset to Original"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </form>

        <div className="px-6 sm:px-8 py-3 bg-neutral-950/60 border-t border-neutral-800/80 text-center">
          <p className="text-[10px] text-neutral-500">
            Changes persist in your browser session and update all navigation, badges, hero banners, and checkout vouchers.
          </p>
        </div>
      </div>
    </div>
  );
};
