import React, { useState, useEffect } from 'react';
import {
  Crown,
  Package,
  Sparkles,
  Clock,
  MapPin,
  TrendingUp,
  CreditCard,
  Gift,
  ArrowLeft,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  Copy,
  Plus,
  Trash2,
  Edit3,
  ExternalLink,
  Flame,
  Truck,
  Box,
  Layers,
  ShoppingBag,
  Bell,
  Sliders,
  DollarSign,
  Tag
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useBrand } from '../context/BrandContext';
import { SAMPLE_PRODUCTS } from '../data/products';
import { Order, Product, RewardVoucher, DropEvent, ShippingAddress } from '../types';

interface DashboardProps {
  onBackToStore: () => void;
  onSelectProduct: (product: Product) => void;
}

const UPCOMING_DROPS: DropEvent[] = [
  {
    id: 'drop-5',
    title: 'CYBER-GLIDE 02 LOW RUNNER',
    edition: 'Tokyo Shibuya Night Edition',
    date: 'Dropping Tomorrow at 18:00 JST',
    countdownHours: 14,
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=800&q=80',
    tag: 'VIP EARLY ACCESS',
    price: 260
  },
  {
    id: 'drop-6',
    title: 'NEO-TOKYO GORE-TEX SHELL',
    edition: 'All-Weather Modular Trench',
    date: 'Dropping this Friday',
    countdownHours: 72,
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=800&q=80',
    tag: 'LIMITED 30 PCS',
    price: 395
  },
  {
    id: 'drop-7',
    title: 'TITANIUM CARGO RIG PANT',
    edition: 'Reflective Cinch Silhouette',
    date: 'Dropping Next Week',
    countdownHours: 140,
    image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=800&q=80',
    tag: 'EXCLUSIVE',
    price: 210
  }
];

export const Dashboard: React.FC<DashboardProps> = ({ onBackToStore, onSelectProduct }) => {
  const { user, updateProfile, addAddress, deleteAddress, openAuthModal, isAuthenticated } = useAuth();
  const { orders, applyDiscountCode, setIsCartOpen } = useCart();
  const { brand, openBrandEditor } = useBrand();

  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'drops' | 'rewards' | 'atelier' | 'settings'>('overview');
  const [roleMode, setRoleMode] = useState<'member' | 'manager'>('member');

  // Interactive drop reservations
  const [reservedDrops, setReservedDrops] = useState<string[]>(['drop-5']);
  
  // Interactive vouchers
  const [unlockedVouchers, setUnlockedVouchers] = useState<string[]>(['VOUCH-URBAN20']);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Address form
  const [showAddAddress, setShowAddAddress] = useState(false);
  const [newStreet, setNewStreet] = useState('');
  const [newCity, setNewCity] = useState('');
  const [newState, setNewState] = useState('');
  const [newZip, setNewZip] = useState('');
  const [newCountry, setNewCountry] = useState('United States');

  // Inventory overrides simulation for Manager mode
  const [stockStatus, setStockStatus] = useState<Record<string, boolean>>({
    'prod-1': true,
    'prod-2': true,
    'prod-3': true,
    'prod-4': true,
    'prod-5': false, // sold out simulation
    'prod-6': true,
    'prod-7': true,
    'prod-8': true,
  });

  // Countdown timer simulation
  const [timeLeft, setTimeLeft] = useState({ hours: 14, minutes: 22, seconds: 45 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const currentPoints = user?.memberPoints ?? 1200;
  const currentTier = user?.memberTier ?? 'VIP Elite';

  const tierProgress = {
    'Bronze': { next: 'Silver', target: 500, percent: Math.min(100, (currentPoints / 500) * 100) },
    'Silver': { next: 'Gold', target: 1000, percent: Math.min(100, (currentPoints / 1000) * 100) },
    'Gold': { next: 'VIP Elite', target: 2000, percent: Math.min(100, (currentPoints / 2000) * 100) },
    'VIP Elite': { next: 'Black Obsidian Legend', target: 5000, percent: Math.min(100, (currentPoints / 5000) * 100) },
  }[currentTier] || { next: 'VIP Elite', target: 2000, percent: 75 };

  const handleRedeemVoucher = (code: string, cost: number) => {
    if (currentPoints < cost) {
      alert(`You need ${cost} points to unlock this voucher. Keep collecting drops!`);
      return;
    }

    if (unlockedVouchers.includes(code)) {
      handleCopyCode(code);
      return;
    }

    updateProfile({ memberPoints: currentPoints - cost });
    setUnlockedVouchers((prev) => [...prev, code]);

    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard?.writeText(code);
    setCopiedCode(code);
    applyDiscountCode(code);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const handleToggleReserveDrop = (dropId: string) => {
    setReservedDrops((prev) =>
      prev.includes(dropId) ? prev.filter((id) => id !== dropId) : [...prev, dropId]
    );
    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.7 }
      });
    } catch {
      // ignore
    }
  };

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStreet || !newCity) return;

    addAddress({
      name: user?.name || 'Urban Member',
      street: newStreet,
      city: newCity,
      state: newState,
      zip: newZip,
      country: newCountry,
      isDefault: (user?.addresses || []).length === 0
    });

    setNewStreet('');
    setNewCity('');
    setNewState('');
    setNewZip('');
    setShowAddAddress(false);
  };

  const toggleStock = (prodId: string) => {
    setStockStatus((prev) => ({
      ...prev,
      [prodId]: !prev[prodId]
    }));
  };

  return (
    <div className="min-h-screen bg-[#0a0b0d] text-neutral-100 flex flex-col font-sans">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#0f1013]/90 backdrop-blur-xl border-b border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-20 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <button
              onClick={onBackToStore}
              className="px-3.5 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-bold text-neutral-300 hover:text-white transition-all flex items-center gap-2 group"
            >
              <ArrowLeft className="w-4 h-4 text-amber-400 group-hover:-translate-x-0.5 transition-transform" />
              <span>Back to Storefront</span>
            </button>

            <div className="h-5 w-px bg-neutral-800 hidden sm:block" />

            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-400 text-black flex items-center justify-center font-black text-xs font-display">
                {brand.monogram}
              </div>
              <div className="hidden sm:block">
                <span className="text-sm font-black uppercase text-white font-display block leading-none">
                  {brand.name} Command
                </span>
                <span className="text-[9px] uppercase tracking-wider text-amber-400 font-bold">
                  {roleMode === 'member' ? 'VIP Member Hub' : 'Store Atelier Studio'}
                </span>
              </div>
            </div>
          </div>

          {/* Right Mode Switcher & Edit Brand */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Switch between Member and Manager Mode */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-1 flex items-center text-xs">
              <button
                onClick={() => setRoleMode('member')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                  roleMode === 'member'
                    ? 'bg-amber-400 text-black shadow-md'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Crown className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Member View</span>
              </button>
              <button
                onClick={() => setRoleMode('manager')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1.5 ${
                  roleMode === 'manager'
                    ? 'bg-neutral-800 text-white shadow-md'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">Atelier Studio</span>
              </button>
            </div>

            <button
              onClick={openBrandEditor}
              className="px-3 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-semibold text-neutral-300 hover:text-amber-400 transition-colors flex items-center gap-1.5"
              title="Edit Store Name"
            >
              <Edit3 className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden md:inline">Edit Brand</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Dashboard Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full flex-1 space-y-8">
        {/* User Hero Banner */}
        <div className="relative rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-900 to-neutral-950 border border-neutral-800 p-6 sm:p-8 overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-80 h-80 bg-amber-400/5 rounded-full blur-3xl pointer-events-none" />
          
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-center gap-4 sm:gap-5">
              <div className="relative">
                {user?.avatar ? (
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-amber-400 shadow-xl"
                  />
                ) : (
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-black flex items-center justify-center font-black text-2xl font-display shadow-xl">
                    {user?.name ? user.name.slice(0, 2).toUpperCase() : brand.monogram}
                  </div>
                )}
                <span className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full border-4 border-[#121316]"></span>
              </div>

              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-400/10 text-amber-300 border border-amber-400/30 flex items-center gap-1">
                    <Crown className="w-3 h-3 text-amber-400" />
                    <span>{currentTier}</span>
                  </span>
                  <span className="text-xs text-neutral-500">
                    {user?.joinedDate || 'Member Since 2026'}
                  </span>
                </div>

                <h1 className="text-2xl sm:text-3xl font-black text-white uppercase font-display tracking-tight">
                  {user?.name || 'Urban Fashion VIP'}
                </h1>
                <p className="text-xs text-neutral-400">
                  {user?.email || 'asadkhaan76762@gmail.com'} • Style Identity: <strong className="text-white">{user?.preferredStyle || 'Streetwear'}</strong>
                </p>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center gap-3">
              {!isAuthenticated ? (
                <button
                  onClick={() => openAuthModal('signup')}
                  className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-black font-extrabold uppercase text-xs rounded-xl transition-all shadow-lg shadow-amber-400/20 font-display flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Claim +600 Welcome Points</span>
                </button>
              ) : (
                <button
                  onClick={() => setActiveTab('rewards')}
                  className="px-5 py-3 bg-neutral-800 hover:bg-neutral-700 text-white font-bold uppercase text-xs rounded-xl transition-all border border-neutral-700 flex items-center gap-2"
                >
                  <Gift className="w-4 h-4 text-amber-400" />
                  <span>Redeem Rewards (${Math.floor(currentPoints / 50)} Value)</span>
                </button>
              )}

              <button
                onClick={onBackToStore}
                className="px-5 py-3 bg-white hover:bg-neutral-200 text-black font-bold uppercase text-xs rounded-xl transition-all font-display"
              >
                Browse Shop
              </button>
            </div>
          </div>
        </div>

        {/* Dynamic KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {roleMode === 'member' ? (
            <>
              {/* Points Balance */}
              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="uppercase font-semibold tracking-wider">UrbanPoints</span>
                  <Sparkles className="w-4 h-4 text-amber-400" />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-white font-display">
                    {currentPoints.toLocaleString()}
                  </span>
                  <span className="text-xs text-amber-400 font-bold">PTS</span>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] text-neutral-500 font-mono">
                    <span>Next: {tierProgress.next}</span>
                    <span>{Math.round(tierProgress.percent)}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-amber-400 to-amber-500 rounded-full"
                      style={{ width: `${tierProgress.percent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Active Orders */}
              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="uppercase font-semibold tracking-wider">Orders In Flight</span>
                  <Truck className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-white font-display">
                    {orders.length}
                  </span>
                  <span className="text-xs text-cyan-400 font-bold">SHIPMENTS</span>
                </div>
                <p className="text-[11px] text-neutral-400">
                  {orders[0] ? (
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                      {orders[0].status} ({orders[0].id})
                    </span>
                  ) : (
                    'Ready for your next drop'
                  )}
                </p>
              </div>

              {/* Drop Radar Countdown */}
              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="uppercase font-semibold tracking-wider">Next Drop Radar</span>
                  <Clock className="w-4 h-4 text-rose-400" />
                </div>
                <div className="font-mono text-2xl font-black text-white">
                  {String(timeLeft.hours).padStart(2, '0')}:{String(timeLeft.minutes).padStart(2, '0')}:{String(timeLeft.seconds).padStart(2, '0')}
                </div>
                <p className="text-[11px] text-rose-400 font-semibold truncate">
                  Cyber-Glide 02 Shibuya
                </p>
              </div>

              {/* Unlocked Vouchers */}
              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="uppercase font-semibold tracking-wider">Unlocked Vouchers</span>
                  <Tag className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black text-white font-display">
                    {unlockedVouchers.length + 1}
                  </span>
                  <span className="text-xs text-emerald-400 font-bold">READY</span>
                </div>
                <p className="text-[11px] text-emerald-400 font-medium">
                  Code URBAN20 active (20% OFF)
                </p>
              </div>
            </>
          ) : (
            <>
              {/* Store Analytics for Manager Studio */}
              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="uppercase font-semibold tracking-wider">Gross Drop Revenue</span>
                  <DollarSign className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-3xl font-black text-white font-display">$24,680</div>
                <div className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" /> +38% Tokyo Season Surge
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="uppercase font-semibold tracking-wider">Total Orders Dispatched</span>
                  <Package className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="text-3xl font-black text-white font-display">148</div>
                <p className="text-[11px] text-neutral-400">99.8% On-time delivery SLA</p>
              </div>

              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="uppercase font-semibold tracking-wider">Catalog SKUs In-Stock</span>
                  <Box className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-3xl font-black text-white font-display">
                  {Object.values(stockStatus).filter(Boolean).length} / {SAMPLE_PRODUCTS.length}
                </div>
                <p className="text-[11px] text-amber-400 font-semibold">1 SKU Sold Out</p>
              </div>

              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="uppercase font-semibold tracking-wider">Active VIP Community</span>
                  <Crown className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-3xl font-black text-white font-display">1,842</div>
                <p className="text-[11px] text-neutral-400">84% reserved sizing usage</p>
              </div>
            </>
          )}
        </div>

        {/* Dashboard Tabs Bar */}
        <div className="border-b border-neutral-800 flex overflow-x-auto gap-2 text-xs">
          {[
            { id: 'overview', label: 'VIP Overview', icon: Crown },
            { id: 'orders', label: `Orders & Tracking (${orders.length})`, icon: Package },
            { id: 'drops', label: 'Drop Calendar & Radar', icon: Flame },
            { id: 'rewards', label: 'Rewards & Vouchers', icon: Gift },
            { id: 'atelier', label: 'Atelier Studio / Catalog', icon: Sliders },
            { id: 'settings', label: 'Address & Profile', icon: MapPin },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 px-4 font-bold uppercase tracking-wider rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-neutral-900 text-amber-400 border-b-2 border-amber-400 shadow-md'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-900/50'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left Col: Digital VIP Hologram Card & Recent Orders */}
            <div className="lg:col-span-7 space-y-6">
              {/* Digital Hologram VIP Card */}
              <div className="relative p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-neutral-900 via-neutral-850 to-neutral-950 border border-neutral-700/80 shadow-2xl overflow-hidden group">
                <div className="absolute -right-16 -top-16 w-56 h-56 bg-gradient-to-br from-amber-400/20 to-transparent rounded-full blur-2xl group-hover:scale-125 transition-transform duration-700" />
                <div className="absolute inset-0 bg-[radial-gradient(#ffffff0a_1px,transparent_1px)] [background-size:16px_16px]" />

                <div className="relative z-10 flex flex-col justify-between h-56 sm:h-64">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl bg-amber-400 text-black flex items-center justify-center font-black font-display text-base">
                        {brand.monogram}
                      </div>
                      <div>
                        <span className="font-black text-white text-base tracking-tight font-display uppercase block">
                          {brand.name}
                        </span>
                        <span className="text-[10px] text-amber-400 uppercase tracking-widest font-bold">
                          VIP PASSPORT • LEVEL 4
                        </span>
                      </div>
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-amber-400/20 text-amber-300 border border-amber-400/40">
                      {currentTier}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] font-mono tracking-widest text-neutral-400 uppercase block">
                      MEMBER ID
                    </span>
                    <span className="font-mono text-sm sm:text-base font-bold text-neutral-200 tracking-wider">
                      URB-765C-9941-8293
                    </span>
                  </div>

                  <div className="flex justify-between items-end pt-3 border-t border-neutral-800">
                    <div>
                      <span className="text-[9px] uppercase tracking-wider text-neutral-500 block">
                        CARDHOLDER
                      </span>
                      <span className="text-sm font-bold text-white uppercase font-display">
                        {user?.name || 'Asad Khan'}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[9px] uppercase tracking-wider text-neutral-500 block">
                        POINTS VALUE
                      </span>
                      <span className="text-sm font-black text-amber-400 font-display">
                        {currentPoints} PTS (${Math.floor(currentPoints / 50)})
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Active Order Progress Timeline */}
              <div className="p-6 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-amber-400" />
                    <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                      Live Delivery Tracking
                    </h3>
                  </div>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-xs text-amber-400 hover:underline font-semibold"
                  >
                    View All Orders →
                  </button>
                </div>

                {orders.length === 0 ? (
                  <p className="text-xs text-neutral-500 py-4">No active orders. Shop the drops to track live dispatch.</p>
                ) : (
                  <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-4">
                    <div className="flex justify-between items-center text-xs">
                      <div>
                        <span className="font-mono font-bold text-white">{orders[0].id}</span>
                        <span className="text-[10px] text-neutral-400 block">{orders[0].date}</span>
                      </div>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-400/10 text-amber-400 border border-amber-400/30">
                        {orders[0].status}
                      </span>
                    </div>

                    {/* Timeline bar */}
                    <div className="grid grid-cols-4 gap-2 pt-2 text-center text-[10px]">
                      {[
                        { step: 'Confirmed', done: true },
                        { step: 'Inspected', done: true },
                        { step: 'In Flight', done: orders[0].status !== 'Processing' },
                        { step: 'Delivered', done: orders[0].status === 'Delivered' }
                      ].map((s, idx) => (
                        <div key={idx} className="space-y-1.5">
                          <div
                            className={`h-1.5 rounded-full transition-all ${
                              s.done ? 'bg-amber-400' : 'bg-neutral-800'
                            }`}
                          />
                          <span className={s.done ? 'text-neutral-200 font-bold' : 'text-neutral-500'}>
                            {s.step}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right Col: Drop Radar & Quick Rewards */}
            <div className="lg:col-span-5 space-y-6">
              {/* Upcoming Sneaker Drop Highlight */}
              <div className="p-6 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Flame className="w-4 h-4 text-rose-500" />
                    <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                      Next Tokyo Drop
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-full">
                    PRIORITY QUEUE
                  </span>
                </div>

                <div className="relative aspect-[16/10] rounded-2xl overflow-hidden bg-neutral-950">
                  <img
                    src={UPCOMING_DROPS[0].image}
                    alt={UPCOMING_DROPS[0].title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                  <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
                    <div>
                      <h4 className="text-xs font-bold text-white uppercase">{UPCOMING_DROPS[0].title}</h4>
                      <p className="text-[10px] text-neutral-400">{UPCOMING_DROPS[0].edition}</p>
                    </div>
                    <span className="text-sm font-black text-white">${UPCOMING_DROPS[0].price}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <button
                    onClick={() => handleToggleReserveDrop(UPCOMING_DROPS[0].id)}
                    className={`w-full py-2.5 rounded-xl text-xs font-bold uppercase transition-all flex items-center justify-center gap-1.5 ${
                      reservedDrops.includes(UPCOMING_DROPS[0].id)
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-amber-400 hover:bg-amber-300 text-black'
                    }`}
                  >
                    {reservedDrops.includes(UPCOMING_DROPS[0].id) ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Size Reserved (US 9.5)</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>Reserve My Size</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Quick Coupon Codes */}
              <div className="p-6 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                    <Tag className="w-3.5 h-3.5 text-amber-400" />
                    <span>Active Member Vouchers</span>
                  </h3>
                  <button
                    onClick={() => setActiveTab('rewards')}
                    className="text-[11px] text-amber-400 hover:underline"
                  >
                    Get More →
                  </button>
                </div>

                <div className="space-y-2">
                  <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <span className="font-mono font-bold text-amber-400">URBAN20</span>
                      <span className="text-[10px] text-neutral-400 block">20% VIP Drop Discount</span>
                    </div>
                    <button
                      onClick={() => handleCopyCode('URBAN20')}
                      className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                    >
                      {copiedCode === 'URBAN20' ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedCode === 'URBAN20' ? 'Applied!' : 'Copy'}</span>
                    </button>
                  </div>

                  <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <span className="font-mono font-bold text-emerald-400">VIPFREESHIP</span>
                      <span className="text-[10px] text-neutral-400 block">Complimentary Express Global Courier</span>
                    </div>
                    <button
                      onClick={() => handleCopyCode('VIPFREESHIP')}
                      className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                    >
                      {copiedCode === 'VIPFREESHIP' ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedCode === 'VIPFREESHIP' ? 'Applied!' : 'Copy'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: ORDERS & TRACKING */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-xl font-bold uppercase tracking-tight text-white font-display">
                  Order History & Real-Time Tracking
                </h2>
                <p className="text-xs text-neutral-400">
                  Every order includes cryptographic RFID authenticity and live GPS tracking.
                </p>
              </div>
              <button
                onClick={onBackToStore}
                className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-black text-xs font-bold uppercase rounded-xl transition-colors self-start sm:self-auto"
              >
                Shop New Drops
              </button>
            </div>

            {orders.length === 0 ? (
              <div className="text-center py-16 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-3">
                <Package className="w-12 h-12 text-neutral-600 mx-auto" />
                <h3 className="text-sm font-bold text-white uppercase">No Orders Placed Yet</h3>
                <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                  Add exclusive pieces to your bag and check out to view live dispatch milestones.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((order) => (
                  <div
                    key={order.id}
                    className="p-6 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-4"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-neutral-800">
                      <div>
                        <span className="font-mono text-sm font-bold text-white">{order.id}</span>
                        <span className="text-xs text-neutral-500 block">{order.date}</span>
                      </div>

                      <div className="flex items-center gap-3">
                        <span
                          className={`text-xs font-bold px-3 py-1 rounded-full uppercase ${
                            order.status === 'Delivered'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : 'bg-amber-400/10 text-amber-400 border border-amber-400/30 animate-pulse'
                          }`}
                        >
                          {order.status}
                        </span>
                        <span className="text-base font-black text-white font-display">
                          ${order.totalAmount}
                        </span>
                      </div>
                    </div>

                    {/* Order items */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {order.items.map((item, i) => (
                        <div key={i} className="p-3 bg-neutral-950 border border-neutral-800/80 rounded-2xl flex items-center gap-3">
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="w-14 h-14 rounded-xl object-cover bg-neutral-800"
                          />
                          <div className="flex-1 min-w-0">
                            <h4 className="text-xs font-bold text-white truncate">{item.product.name}</h4>
                            <p className="text-[11px] text-neutral-400">Size: {item.selectedSize} • Color: {item.selectedColor}</p>
                            <p className="text-[11px] font-bold text-amber-400">${item.product.price} × {item.quantity}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Shipping and Tracking details */}
                    <div className="pt-3 border-t border-neutral-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                      <div className="text-neutral-400">
                        Destination: <strong className="text-white">{order.shippingAddress.street}, {order.shippingAddress.city}</strong>
                      </div>
                      <div className="text-neutral-400 flex items-center gap-2">
                        <span>Courier Waybill:</span>
                        <span className="font-mono font-bold text-amber-400">{order.trackingNumber}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: DROP CALENDAR & RADAR */}
        {activeTab === 'drops' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold uppercase tracking-tight text-white font-display">
                  Tokyo & New York Drop Calendar
                </h2>
                <p className="text-xs text-neutral-400">
                  Exclusive limited releases. Reserve your sizing ahead of public drops.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {UPCOMING_DROPS.map((drop) => {
                const isReserved = reservedDrops.includes(drop.id);
                return (
                  <div
                    key={drop.id}
                    className="p-5 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-4 flex flex-col justify-between group hover:border-neutral-700 transition-colors"
                  >
                    <div className="space-y-3">
                      <div className="relative aspect-[4/3] rounded-2xl overflow-hidden bg-neutral-950">
                        <img
                          src={drop.image}
                          alt={drop.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <span className="absolute top-2.5 left-2.5 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-black/80 text-amber-400 border border-amber-400/30 backdrop-blur-md">
                          {drop.tag}
                        </span>
                      </div>

                      <div>
                        <span className="text-[10px] text-amber-400 uppercase font-mono font-semibold">
                          {drop.date}
                        </span>
                        <h3 className="text-sm font-bold text-white uppercase mt-0.5 font-display">{drop.title}</h3>
                        <p className="text-xs text-neutral-400">{drop.edition}</p>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-neutral-800 flex items-center justify-between">
                      <span className="text-base font-black text-white font-display">${drop.price}</span>
                      <button
                        onClick={() => handleToggleReserveDrop(drop.id)}
                        className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase transition-all flex items-center gap-1.5 ${
                          isReserved
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-amber-400 hover:bg-amber-300 text-black'
                        }`}
                      >
                        {isReserved ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                        <span>{isReserved ? 'Reserved' : 'Reserve Sizing'}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 4: REWARDS & VOUCHERS */}
        {activeTab === 'rewards' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold uppercase tracking-tight text-white font-display">
                Loyalty Rewards Center
              </h2>
              <p className="text-xs text-neutral-400">
                You have <strong className="text-amber-400 font-bold">{currentPoints} UrbanPoints</strong> available. Redeem for discount coupons.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {[
                { code: 'PASS-10-DROP', amount: 10, cost: 500, label: '$10 Drop Voucher' },
                { code: 'VIP-25-PASS', amount: 25, cost: 1000, label: '$25 Atelier Pass' },
                { code: 'ELITE-50-GRAIL', amount: 50, cost: 1800, label: '$50 Grails Credit' },
              ].map((voucher) => {
                const isUnlocked = unlockedVouchers.includes(voucher.code);
                return (
                  <div
                    key={voucher.code}
                    className="p-6 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-4 flex flex-col justify-between"
                  >
                    <div className="space-y-2">
                      <div className="w-10 h-10 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center">
                        <Gift className="w-5 h-5" />
                      </div>
                      <h3 className="text-base font-bold text-white uppercase font-display">{voucher.label}</h3>
                      <p className="text-xs text-neutral-400">
                        Redeemable on all footwear, outerwear, and accessories.
                      </p>
                      <div className="text-xs font-mono text-amber-400 font-bold">
                        Cost: {voucher.cost} Points
                      </div>
                    </div>

                    <div className="pt-4 border-t border-neutral-800">
                      {isUnlocked ? (
                        <button
                          onClick={() => handleCopyCode(voucher.code)}
                          className="w-full py-2.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-bold uppercase flex items-center justify-center gap-1.5"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          <span>{copiedCode === voucher.code ? 'Copied to Bag!' : `Copy ${voucher.code}`}</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleRedeemVoucher(voucher.code, voucher.cost)}
                          disabled={currentPoints < voucher.cost}
                          className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 disabled:opacity-40 text-black rounded-xl text-xs font-extrabold uppercase transition-all shadow-md"
                        >
                          Unlock Voucher
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 5: ATELIER STUDIO / STORE MANAGER */}
        {activeTab === 'atelier' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold uppercase tracking-tight text-white font-display">
                  Atelier Drop & Inventory Studio
                </h2>
                <p className="text-xs text-neutral-400">
                  Control stock status, inspect drop pricing, and customize the store identity.
                </p>
              </div>

              <button
                onClick={openBrandEditor}
                className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-black text-xs font-extrabold uppercase rounded-xl transition-all flex items-center gap-1.5"
              >
                <Edit3 className="w-4 h-4" />
                <span>Customize Store Name</span>
              </button>
            </div>

            {/* Catalog Grid Controls */}
            <div className="p-6 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Live Drop Catalog ({SAMPLE_PRODUCTS.length} SKUs)
              </h3>

              <div className="space-y-3">
                {SAMPLE_PRODUCTS.map((prod) => {
                  const inStock = stockStatus[prod.id] !== false;
                  return (
                    <div
                      key={prod.id}
                      className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={prod.image}
                          alt={prod.name}
                          className="w-12 h-12 rounded-xl object-cover bg-neutral-800 shrink-0"
                        />
                        <div>
                          <h4 className="text-xs font-bold text-white">{prod.name}</h4>
                          <p className="text-[11px] text-neutral-400">{prod.category} • ${prod.price}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => toggleStock(prod.id)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase transition-all ${
                            inStock
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {inStock ? 'In Stock (Live)' : 'Sold Out (Drop Closed)'}
                        </button>

                        <button
                          onClick={() => onSelectProduct(prod)}
                          className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold"
                        >
                          Inspect
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: SETTINGS & ADDRESSES */}
        {activeTab === 'settings' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Address Management */}
            <div className="p-6 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                  Shipping Addresses
                </h3>
                <button
                  onClick={() => setShowAddAddress(!showAddAddress)}
                  className="text-xs text-amber-400 hover:underline font-bold flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add New</span>
                </button>
              </div>

              {showAddAddress && (
                <form onSubmit={handleSaveAddress} className="p-4 bg-neutral-950 border border-amber-400/30 rounded-2xl space-y-2.5">
                  <h4 className="text-xs font-bold text-white uppercase">Add Destination</h4>
                  <input
                    type="text"
                    placeholder="Street Address"
                    value={newStreet}
                    onChange={(e) => setNewStreet(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                    required
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="City"
                      value={newCity}
                      onChange={(e) => setNewCity(e.target.value)}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                      required
                    />
                    <input
                      type="text"
                      placeholder="State / Region"
                      value={newState}
                      onChange={(e) => setNewState(e.target.value)}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div className="flex gap-2 pt-1">
                    <button type="submit" className="flex-1 bg-amber-400 text-black font-bold py-2 rounded-xl text-xs">
                      Save
                    </button>
                    <button type="button" onClick={() => setShowAddAddress(false)} className="px-3 bg-neutral-800 text-neutral-300 py-2 rounded-xl text-xs">
                      Cancel
                    </button>
                  </div>
                </form>
              )}

              <div className="space-y-3">
                {(user?.addresses || []).map((addr) => (
                  <div key={addr.id} className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-2xl flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-white">{addr.name}</p>
                      <p className="text-xs text-neutral-400">{addr.street}, {addr.city}</p>
                      <p className="text-[11px] text-neutral-500">{addr.country} {addr.zip}</p>
                    </div>
                    <button onClick={() => deleteAddress(addr.id)} className="text-neutral-500 hover:text-rose-400 p-1">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Fashion DNA Profile */}
            <div className="p-6 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                Fashion Identity DNA
              </h3>
              <p className="text-xs text-neutral-400">
                Choose your primary style aesthetic to prioritize matching sneaker releases.
              </p>

              <div className="space-y-2">
                {(['Streetwear', 'Techwear', 'Sneakerhead', 'Minimalist', 'Avant-Garde'] as const).map((style) => (
                  <button
                    key={style}
                    onClick={() => updateProfile({ preferredStyle: style })}
                    className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                      (user?.preferredStyle || 'Streetwear') === style
                        ? 'border-amber-400 bg-amber-400/10 text-white font-bold'
                        : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <span className="text-xs">{style}</span>
                    {(user?.preferredStyle || 'Streetwear') === style && (
                      <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
