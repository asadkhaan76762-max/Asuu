import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Music, Disc3, Radio } from 'lucide-react';
import { useBrand } from '../context/BrandContext';

interface Track {
  id: string;
  title: string;
  bpm: string;
  vibe: string;
  baseFreq: number;
}

const RUNWAY_TRACKS: Track[] = [
  { id: '1', title: 'Tokyo Underground 04', bpm: '124 BPM', vibe: 'Deep Minimal Bass', baseFreq: 110 },
  { id: '2', title: 'Cyber Runway Shibuya', bpm: '128 BPM', vibe: 'Electro Chill', baseFreq: 130.81 },
  { id: '3', title: 'Midnight Velvet Walk', bpm: '115 BPM', vibe: 'Lo-Fi Fashion Beat', baseFreq: 98 },
  { id: '4', title: 'Seoul High-Street VIP', bpm: '120 BPM', vibe: 'Nu-Disco Pulse', baseFreq: 123.47 },
];

export const RunwayAudioPlayer: React.FC = () => {
  const { brand } = useBrand();
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [volume, setVolume] = useState(0.4);
  const [isExpanded, setIsExpanded] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const intervalRef = useRef<number | null>(null);

  const currentTrack = RUNWAY_TRACKS[currentTrackIndex];

  // Stop sound on unmount
  useEffect(() => {
    return () => {
      stopAudioEngine();
    };
  }, []);

  const initAudioEngine = () => {
    if (!audioCtxRef.current) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      audioCtxRef.current = new AudioCtx();
      const gainNode = audioCtxRef.current.createGain();
      gainNode.gain.setValueAtTime(volume * 0.15, audioCtxRef.current.currentTime);
      gainNode.connect(audioCtxRef.current.destination);
      gainNodeRef.current = gainNode;
    }

    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  };

  const playSynthPulse = (freq: number, type: OscillatorType = 'sine', duration = 0.25) => {
    if (!audioCtxRef.current || !gainNodeRef.current) return;
    try {
      const ctx = audioCtxRef.current;
      const osc = ctx.createOscillator();
      const noteGain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);

      // Envelope
      noteGain.gain.setValueAtTime(0.001, ctx.currentTime);
      noteGain.gain.linearRampToValueAtTime(0.2, ctx.currentTime + 0.04);
      noteGain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);

      osc.connect(noteGain);
      noteGain.connect(gainNodeRef.current);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + duration);
    } catch {
      // ignore
    }
  };

  const startAudioLoop = (track: Track) => {
    initAudioEngine();
    stopAudioLoop();

    const root = track.baseFreq;
    const chordNotes = [
      root,
      root * 1.25,      // major 3rd
      root * 1.5,       // 5th
      root * 1.875,     // 7th
      root * 2,         // octave
      root * 0.5        // sub bass
    ];

    let step = 0;
    const intervalMs = Math.round((60 / 124) * 500); // 16th notes feel

    intervalRef.current = window.setInterval(() => {
      if (!audioCtxRef.current) return;
      
      // Kick / Sub pulse on beats 0, 4, 8, 12
      if (step % 4 === 0) {
        playSynthPulse(root * 0.5, 'triangle', 0.28);
      }
      
      // Snare / Hi-hat click on beats 2, 6, 10, 14
      if (step % 4 === 2) {
        playSynthPulse(800 + Math.random() * 400, 'sine', 0.08);
      }

      // Melodic arpeggio fashion chords
      if (step % 2 === 0) {
        const note = chordNotes[(step / 2) % chordNotes.length];
        playSynthPulse(note, 'sine', 0.22);
      }

      step = (step + 1) % 16;
    }, intervalMs);
  };

  const stopAudioLoop = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const stopAudioEngine = () => {
    stopAudioLoop();
    if (audioCtxRef.current && audioCtxRef.current.state !== 'closed') {
      try {
        audioCtxRef.current.suspend();
      } catch {
        // ignore
      }
    }
  };

  const togglePlay = () => {
    if (isPlaying) {
      stopAudioEngine();
      setIsPlaying(false);
    } else {
      startAudioLoop(currentTrack);
      setIsPlaying(true);
    }
  };

  const switchTrack = (index: number) => {
    setCurrentTrackIndex(index);
    if (isPlaying) {
      startAudioLoop(RUNWAY_TRACKS[index]);
    }
  };

  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    if (gainNodeRef.current && audioCtxRef.current) {
      gainNodeRef.current.gain.setValueAtTime(newVol * 0.15, audioCtxRef.current.currentTime);
    }
  };

  return (
    <div className="relative">
      <div className="flex items-center gap-2 bg-neutral-900/90 border border-neutral-800 rounded-full px-3 py-1.5 shadow-lg backdrop-blur-md">
        <button
          onClick={togglePlay}
          className={`flex items-center gap-2 text-xs font-semibold px-2.5 py-1 rounded-full transition-all ${
            isPlaying
              ? 'bg-amber-400 text-black shadow-[0_0_15px_rgba(251,191,36,0.5)]'
              : 'bg-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-700'
          }`}
          title={isPlaying ? 'Pause Runway Soundtrack' : 'Play Runway Fashion Music'}
        >
          {isPlaying ? (
            <Disc3 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Radio className="w-3.5 h-3.5 text-amber-400" />
          )}
          <span>{isPlaying ? 'RUNWAY LIVE' : 'PLAY RUNWAY'}</span>
        </button>

        {/* Visualizer bars */}
        {isPlaying && (
          <div className="flex items-end gap-0.5 h-3.5 px-1">
            <span className="w-0.5 bg-amber-400 rounded-full animate-pulse h-2"></span>
            <span className="w-0.5 bg-amber-400 rounded-full animate-bounce h-3.5"></span>
            <span className="w-0.5 bg-amber-400 rounded-full animate-pulse h-2.5"></span>
            <span className="w-0.5 bg-amber-400 rounded-full animate-bounce h-3"></span>
          </div>
        )}

        {/* Track info button */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-xs text-neutral-400 hover:text-white flex items-center gap-1.5 px-1"
        >
          <Music className="w-3 h-3 text-neutral-400" />
          <span className="hidden sm:inline max-w-[110px] truncate">{currentTrack.title}</span>
        </button>

        {/* Volume toggle */}
        <button
          onClick={() => handleVolumeChange(volume === 0 ? 0.4 : 0)}
          className="text-neutral-400 hover:text-white transition-colors"
          title="Toggle Mute"
        >
          {volume === 0 ? <VolumeX className="w-3.5 h-3.5 text-neutral-500" /> : <Volume2 className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Popout track selection menu */}
      {isExpanded && (
        <div className="absolute right-0 mt-2 w-72 bg-neutral-900 border border-neutral-800 rounded-2xl p-4 shadow-2xl z-50 backdrop-blur-xl animate-in fade-in zoom-in-95">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <Disc3 className="w-4 h-4 text-amber-400 animate-spin" />
              <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-200">
                {brand.name} Runway Radio
              </h4>
            </div>
            <span className="text-[10px] bg-neutral-800 text-amber-400 px-2 py-0.5 rounded-full font-mono">
              SYNTH 2.0
            </span>
          </div>

          <p className="text-[11px] text-neutral-400 mb-3">
            Immersive live synthesizer soundscape modeled for streetwear runways & catwalk drops.
          </p>

          <div className="space-y-1.5 mb-4">
            {RUNWAY_TRACKS.map((t, idx) => (
              <button
                key={t.id}
                onClick={() => switchTrack(idx)}
                className={`w-full text-left p-2 rounded-xl text-xs flex items-center justify-between transition-all ${
                  idx === currentTrackIndex
                    ? 'bg-amber-400/10 border border-amber-400/40 text-amber-300 font-semibold'
                    : 'hover:bg-neutral-800/60 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <div>
                  <div className="text-neutral-200 font-medium">{t.title}</div>
                  <div className="text-[10px] text-neutral-500">{t.vibe}</div>
                </div>
                <span className="text-[10px] text-neutral-400 font-mono">{t.bpm}</span>
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-neutral-800 flex items-center justify-between">
            <span className="text-[11px] text-neutral-400">Master Level</span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
              className="w-28 accent-amber-400 h-1 bg-neutral-800 rounded-lg cursor-pointer"
            />
          </div>
        </div>
      )}
    </div>
  );
};
