import React from 'react';
import { Sparkles, Gift, Crown, Clock, Music, ArrowRight, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useBrand } from '../context/BrandContext';

export const MemberPerksBanner: React.FC = () => {
  const { isAuthenticated, openAuthModal, user } = useAuth();
  const { brand } = useBrand();

  return (
    <section className="py-16 bg-gradient-to-b from-neutral-950 to-[#0c0d0e] border-t border-b border-neutral-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl bg-neutral-900 border border-neutral-800 p-8 sm:p-12 overflow-hidden shadow-2xl">
          {/* Background decorative elements */}
          <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -left-20 -top-20 w-80 h-80 bg-cyan-400/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-amber-400" />
                <span className="text-xs font-black uppercase tracking-widest text-amber-400">
                  {brand.name.toUpperCase()} VIP PASSPORT
                </span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight font-display">
                Elevate Your Drop Access. <br />
                <span className="text-amber-400">Sign Up & Claim 600 Points</span> Today.
              </h2>

              <p className="text-xs sm:text-sm text-neutral-400 max-w-xl leading-relaxed">
                {brand.name} drops sell out within minutes. As a registered member, your shoe sizes are reserved, 
                you unlock 15% automatic VIP tiers, and receive personal concierge tracking.
              </p>

              {/* Perks grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3">
                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded-lg bg-amber-400/10 text-amber-400 shrink-0">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">600 Instant Welcome Points</h4>
                    <p className="text-[11px] text-neutral-500">Immediate $12 redeemable coupon</p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded-lg bg-cyan-400/10 text-cyan-400 shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">2-Hour Drop Headstart</h4>
                    <p className="text-[11px] text-neutral-500">Access limited colorways first</p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded-lg bg-emerald-400/10 text-emerald-400 shrink-0">
                    <Gift className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Birthday Gift Drops</h4>
                    <p className="text-[11px] text-neutral-500">Free accessory item every year</p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded-lg bg-rose-400/10 text-rose-400 shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Free Priority Returns</h4>
                    <p className="text-[11px] text-neutral-500">No questions asked 30-day window</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Card / CTA */}
            <div className="lg:col-span-5">
              <div className="bg-[#121316] border border-neutral-800 rounded-2xl p-6 sm:p-8 space-y-5 text-center shadow-xl">
                {!isAuthenticated ? (
                  <>
                    <div className="w-12 h-12 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center mx-auto">
                      <Sparkles className="w-6 h-6" />
                    </div>

                    <div>
                      <h3 className="text-xl font-black text-white uppercase font-display">
                        Ready to Join?
                      </h3>
                      <p className="text-xs text-neutral-400 mt-1">
                        Free membership. Zero commitments. Takes under 30 seconds.
                      </p>
                    </div>

                    <div className="space-y-2.5">
                      <button
                        onClick={() => openAuthModal('signup')}
                        className="w-full py-3.5 bg-amber-400 hover:bg-amber-300 text-black font-extrabold uppercase rounded-xl transition-all shadow-lg shadow-amber-400/20 flex items-center justify-center gap-2 font-display text-xs"
                      >
                        <span>Create Account (+600 PTS)</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => openAuthModal('signin')}
                        className="w-full py-3 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-white font-bold uppercase rounded-xl transition-colors text-xs"
                      >
                        Already a Member? Sign In
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                      <Crown className="w-6 h-6" />
                    </div>

                    <div>
                      <h3 className="text-xl font-black text-white uppercase font-display">
                        VIP Passport Active
                      </h3>
                      <p className="text-xs text-neutral-400 mt-1">
                        Welcome, <span className="text-white font-bold">{user?.name}</span>. You have access to all member privileges.
                      </p>
                    </div>

                    <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800 text-xs text-left space-y-1.5">
                      <div className="flex justify-between text-neutral-400">
                        <span>Current Tier</span>
                        <span className="text-amber-400 font-bold">{user?.memberTier}</span>
                      </div>
                      <div className="flex justify-between text-neutral-400">
                        <span>Points Stash</span>
                        <span className="text-white font-bold">{user?.memberPoints} PTS</span>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
