import React, { createContext, useContext, useState, useEffect } from 'react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { BrandConfig } from '../types';
import { db, auth } from '../firebase';

interface BrandContextType {
  brand: BrandConfig;
  isBrandEditorOpen: boolean;
  openBrandEditor: () => void;
  closeBrandEditor: () => void;
  updateBrand: (updates: Partial<BrandConfig>) => void;
  resetBrand: () => void;
  applyPreset: (presetName: string) => void;
}

const BRAND_STORAGE_KEY = 'urbanstep_custom_brand_config';

export const BRAND_PRESETS: { label: string; config: BrandConfig }[] = [
  {
    label: 'UrbanStep (Original)',
    config: {
      name: 'UrbanStep',
      tagline: 'Fashion Collective',
      monogram: 'US',
      foundedYear: '2026',
      accentTheme: 'amber'
    }
  },
  {
    label: 'Khaan Streetwear',
    config: {
      name: 'Khaan Step',
      tagline: 'Luxury Streetwear & Atelier',
      monogram: 'KS',
      foundedYear: '2026',
      accentTheme: 'amber'
    }
  },
  {
    label: 'Apex Runner',
    config: {
      name: 'Apex Runner',
      tagline: 'High-Tech Footwear Lab',
      monogram: 'AR',
      foundedYear: '2026',
      accentTheme: 'cyan'
    }
  },
  {
    label: 'Tokyo Rogue',
    config: {
      name: 'Tokyo Rogue',
      tagline: 'Subversive Runway Drop',
      monogram: 'TR',
      foundedYear: '2026',
      accentTheme: 'rose'
    }
  },
  {
    label: 'Vortex Noir',
    config: {
      name: 'Vortex Noir',
      tagline: 'Avant-Garde Technical Gear',
      monogram: 'VN',
      foundedYear: '2026',
      accentTheme: 'emerald'
    }
  }
];

const DEFAULT_BRAND: BrandConfig = BRAND_PRESETS[0].config;

const BrandContext = createContext<BrandContextType | undefined>(undefined);

export const BrandProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [brand, setBrand] = useState<BrandConfig>(DEFAULT_BRAND);
  const [isBrandEditorOpen, setIsBrandEditorOpen] = useState(false);

  useEffect(() => {
    // 1. Initial load from local storage
    try {
      const saved = localStorage.getItem(BRAND_STORAGE_KEY);
      if (saved) {
        setBrand(JSON.parse(saved));
      }
    } catch {
      // fallback
    }

    // 2. Sync from Firestore
    async function loadFromFirestore() {
      try {
        const snap = await getDoc(doc(db, 'brand_settings', 'default'));
        if (snap.exists()) {
          const cloudData = snap.data() as BrandConfig;
          if (cloudData.name) {
            setBrand(cloudData);
            localStorage.setItem(BRAND_STORAGE_KEY, JSON.stringify(cloudData));
          }
        }
      } catch {
        // graceful offline fallback
      }
    }
    loadFromFirestore();
  }, []);

  useEffect(() => {
    // Sync browser tab title
    document.title = `${brand.name} — Luxury Streetwear & Sneaker Collective`;
  }, [brand.name]);

  const updateBrand = (updates: Partial<BrandConfig>) => {
    setBrand((prev) => {
      const next: BrandConfig = {
        ...prev,
        ...updates
      };
      
      // Auto-compute monogram if name changed and monogram wasn't explicitly supplied
      if (updates.name && !updates.monogram) {
        const parts = updates.name.trim().split(/\s+/);
        if (parts.length >= 2) {
          next.monogram = (parts[0][0] + parts[1][0]).toUpperCase();
        } else if (parts[0].length >= 2) {
          next.monogram = parts[0].slice(0, 2).toUpperCase();
        } else {
          next.monogram = parts[0].toUpperCase();
        }
      }

      try {
        localStorage.setItem(BRAND_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }

      if (auth.currentUser) {
        try {
          setDoc(doc(db, 'brand_settings', 'default'), {
            name: next.name,
            tagline: next.tagline,
            monogram: next.monogram,
            accentTheme: next.accentTheme,
            updatedAt: new Date().toISOString()
          }, { merge: true });
        } catch {
          // ignore
        }
      }

      return next;
    });
  };

  const resetBrand = () => {
    setBrand(DEFAULT_BRAND);
    localStorage.removeItem(BRAND_STORAGE_KEY);
  };

  const applyPreset = (presetName: string) => {
    const found = BRAND_PRESETS.find((p) => p.label === presetName || p.config.name.toLowerCase() === presetName.toLowerCase());
    if (found) {
      setBrand(found.config);
      localStorage.setItem(BRAND_STORAGE_KEY, JSON.stringify(found.config));
    }
  };

  return (
    <BrandContext.Provider
      value={{
        brand,
        isBrandEditorOpen,
        openBrandEditor: () => setIsBrandEditorOpen(true),
        closeBrandEditor: () => setIsBrandEditorOpen(false),
        updateBrand,
        resetBrand,
        applyPreset
      }}
    >
      {children}
    </BrandContext.Provider>
  );
};

export const useBrand = () => {
  const context = useContext(BrandContext);
  if (!context) {
    throw new Error('useBrand must be used within a BrandProvider');
  }
  return context;
};
