import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { doc, setDoc } from 'firebase/firestore';
import { CartItem, Product, Order, ShippingAddress } from '../types';
import { useAuth } from './AuthContext';
import { db, auth } from '../firebase';

interface CartContextType {
  cart: CartItem[];
  wishlist: Product[];
  orders: Order[];
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  addToCart: (product: Product, size: string, color: string, quantity?: number) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, delta: number) => void;
  clearCart: () => void;
  toggleWishlist: (product: Product) => void;
  isInWishlist: (productId: string) => boolean;
  cartCount: number;
  subtotal: number;
  discount: number;
  discountCode: string;
  applyDiscountCode: (code: string) => { valid: boolean; message: string };
  total: number;
  shippingFee: number;
  placeOrder: (shippingAddress: ShippingAddress) => Promise<Order>;
  selectedProductForQuickView: Product | null;
  setSelectedProductForQuickView: (product: Product | null) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const CART_KEY = 'urbanstep_cart_items';
const WISHLIST_KEY = 'urbanstep_wishlist_items';
const ORDERS_KEY = 'urbanstep_orders_history';

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, updateProfile } = useAuth();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [discountCode, setDiscountCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [selectedProductForQuickView, setSelectedProductForQuickView] = useState<Product | null>(null);

  // Load state from localStorage
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem(CART_KEY);
      if (savedCart) setCart(JSON.parse(savedCart));

      const savedWishlist = localStorage.getItem(WISHLIST_KEY);
      if (savedWishlist) setWishlist(JSON.parse(savedWishlist));

      const savedOrders = localStorage.getItem(ORDERS_KEY);
      if (savedOrders) {
        setOrders(JSON.parse(savedOrders));
      } else {
        // Preload sample order for rich UX
        const initialOrder: Order = {
          id: 'ORD-7829-TOKYO',
          date: 'Yesterday at 18:42',
          items: [
            {
              id: 'sample-cart-item-1',
              product: {
                id: 'prod-1',
                name: 'KINETIC VORTEX 01 SNEAKER',
                subtitle: 'Chunky Sculpted Tech Runner',
                category: 'Sneakers',
                price: 240,
                image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1000&q=80',
                gallery: [],
                sizes: ['US 9.5'],
                colors: [{ name: 'Onyx Black', hex: '#111111' }],
                rating: 4.9,
                reviewsCount: 142,
                description: '',
                details: [],
                inStock: true
              },
              selectedSize: 'US 9.5',
              selectedColor: 'Onyx Black',
              quantity: 1
            }
          ],
          totalAmount: 240,
          status: 'Out for Delivery',
          trackingNumber: 'TRK-JP-99418293',
          shippingAddress: {
            id: 'addr-default',
            isDefault: true,
            name: 'Asad Khan',
            street: '742 Evergreen Terrace, Apt 4B',
            city: 'Tokyo',
            state: 'Shibuya',
            zip: '150-0001',
            country: 'Japan'
          }
        };
        setOrders([initialOrder]);
        localStorage.setItem(ORDERS_KEY, JSON.stringify([initialOrder]));
      }
    } catch {
      // fallback
    }
  }, []);

  // Save changes
  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem(WISHLIST_KEY, JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
  }, [orders]);

  const addToCart = (product: Product, size: string, color: string, quantity = 1) => {
    const itemId = `${product.id}-${size}-${color}`;
    setCart((prev) => {
      const existing = prev.find((item) => item.id === itemId);
      if (existing) {
        return prev.map((item) =>
          item.id === itemId ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { id: itemId, product, selectedSize: size, selectedColor: color, quantity }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (cartItemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== cartItemId));
  };

  const updateQuantity = (cartItemId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.id === cartItemId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        return prev.filter((p) => p.id !== product.id);
      } else {
        return [...prev, product];
      }
    });
  };

  const isInWishlist = (productId: string) => {
    return wishlist.some((p) => p.id === productId);
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discount = Math.round((subtotal * discountPercent) / 100);
  const shippingFee = subtotal > 150 || subtotal === 0 ? 0 : 15;
  const total = Math.max(0, subtotal - discount + (subtotal > 0 ? shippingFee : 0));

  const applyDiscountCode = (code: string) => {
    const clean = code.trim().toUpperCase();
    if (clean === 'URBAN20' || clean === 'MEMBER20') {
      setDiscountCode(clean);
      setDiscountPercent(20);
      return { valid: true, message: 'VIP 20% discount unlocked!' };
    }
    if (clean === 'FIRST10') {
      setDiscountCode(clean);
      setDiscountPercent(10);
      return { valid: true, message: 'Welcome 10% discount applied!' };
    }
    return { valid: false, message: 'Invalid promo code. Try "URBAN20"' };
  };

  const placeOrder = async (shippingAddress: ShippingAddress): Promise<Order> => {
    const newOrder: Order = {
      id: `ORD-${Math.floor(1000 + Math.random() * 9000)}-${Date.now().toString().slice(-4)}`,
      date: 'Just now',
      items: [...cart],
      totalAmount: total,
      status: 'Processing',
      trackingNumber: `TRK-URB-${Math.floor(10000000 + Math.random() * 90000000)}`,
      shippingAddress
    };

    const updatedOrders = [newOrder, ...orders];
    setOrders(updatedOrders);
    clearCart();

    // Persist to Firestore if user is authenticated
    if (auth.currentUser) {
      try {
        setDoc(doc(db, 'orders', newOrder.id), {
          id: newOrder.id,
          userId: auth.currentUser.uid,
          totalAmount: newOrder.totalAmount,
          status: newOrder.status,
          trackingNumber: newOrder.trackingNumber,
          date: newOrder.date,
          createdAt: new Date().toISOString()
        });
      } catch {
        // graceful fallback
      }
    }

    // Add reward points if user is logged in
    if (user) {
      const earnedPoints = Math.round(total);
      updateProfile({
        memberPoints: (user.memberPoints || 0) + earnedPoints
      });
    }

    try {
      confetti({
        particleCount: 120,
        spread: 90,
        origin: { y: 0.5 },
        colors: ['#00f2fe', '#ffd700', '#ffffff', '#ff007f']
      });
    } catch {
      // ignore
    }

    return newOrder;
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        wishlist,
        orders,
        isCartOpen,
        setIsCartOpen,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        toggleWishlist,
        isInWishlist,
        cartCount,
        subtotal,
        discount,
        discountCode,
        applyDiscountCode,
        total,
        shippingFee,
        placeOrder,
        selectedProductForQuickView,
        setSelectedProductForQuickView
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
