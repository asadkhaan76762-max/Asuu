import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { User, AuthMode, ShippingAddress } from '../types';
import { auth, db, googleProvider, signInWithPopup, fbSignOut, handleFirestoreError, OperationType } from '../firebase';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isAuthModalOpen: boolean;
  authMode: AuthMode;
  openAuthModal: (mode?: AuthMode) => void;
  closeAuthModal: () => void;
  switchAuthMode: (mode: AuthMode) => void;
  signIn: (email: string, password?: string) => { success: boolean; message: string };
  signUp: (data: {
    name: string;
    email: string;
    password?: string;
    preferredStyle: User['preferredStyle'];
    subscribeNewsletter?: boolean;
  }) => { success: boolean; message: string };
  signInWithGoogle: () => Promise<{ success: boolean; message: string }>;
  signOut: () => void;
  updateProfile: (data: Partial<User>) => void;
  addAddress: (address: Omit<ShippingAddress, 'id'>) => void;
  deleteAddress: (id: string) => void;
  isProfileDrawerOpen: boolean;
  setIsProfileDrawerOpen: (open: boolean) => void;
  quickDemoLogin: (role?: 'asad' | 'fashionista') => void;
}

const DEFAULT_USERS_KEY = 'urbanstep_registered_users';
const CURRENT_USER_KEY = 'urbanstep_current_user';

const PRELOADED_USERS: User[] = [
  {
    id: 'user-asad',
    name: 'Asad Khan',
    email: 'asadkhaan76762@gmail.com',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    memberTier: 'VIP Elite',
    memberPoints: 1450,
    joinedDate: 'Joined March 2026',
    phone: '+1 (555) 382-9011',
    preferredStyle: 'Streetwear',
    addresses: [
      {
        id: 'addr-1',
        isDefault: true,
        name: 'Asad Khan',
        street: '742 Evergreen Terrace, Apt 4B',
        city: 'Tokyo',
        state: 'Shibuya-ku',
        zip: '150-0001',
        country: 'Japan'
      }
    ]
  },
  {
    id: 'user-elena',
    name: 'Elena Rostova',
    email: 'elena@urbanstep.com',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
    memberTier: 'Gold',
    memberPoints: 850,
    joinedDate: 'Joined January 2026',
    phone: '+1 (555) 789-2244',
    preferredStyle: 'Techwear',
    addresses: [
      {
        id: 'addr-2',
        isDefault: true,
        name: 'Elena Rostova',
        street: '124 Mercer St',
        city: 'New York',
        state: 'NY',
        zip: '10012',
        country: 'United States'
      }
    ]
  }
];

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<AuthMode>('signin');
  const [isProfileDrawerOpen, setIsProfileDrawerOpen] = useState(false);

  // Sync Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        // Fetch or create user document in Firestore
        try {
          const userDocRef = doc(db, 'users', fbUser.uid);
          const snap = await getDoc(userDocRef);

          if (snap.exists()) {
            const data = snap.data();
            const loadedUser: User = {
              id: fbUser.uid,
              name: data.name || fbUser.displayName || 'Member',
              email: fbUser.email || '',
              avatar: fbUser.photoURL || undefined,
              memberTier: data.memberTier || 'VIP Elite',
              memberPoints: data.memberPoints || 1000,
              joinedDate: data.joinedDate || 'Member since 2026',
              preferredStyle: data.preferredStyle || 'Streetwear',
              addresses: data.addresses || []
            };
            setUser(loadedUser);
            localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(loadedUser));
          } else {
            // Create user in Firestore
            const newUser: User = {
              id: fbUser.uid,
              name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Member',
              email: fbUser.email || '',
              avatar: fbUser.photoURL || undefined,
              memberTier: 'VIP Elite',
              memberPoints: 1200,
              joinedDate: 'Joined Today',
              preferredStyle: 'Streetwear',
              addresses: []
            };

            await setDoc(userDocRef, {
              userId: newUser.id,
              name: newUser.name,
              email: newUser.email,
              memberTier: newUser.memberTier,
              memberPoints: newUser.memberPoints,
              preferredStyle: newUser.preferredStyle,
              createdAt: new Date().toISOString()
            });

            setUser(newUser);
            localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(newUser));
          }
        } catch {
          // If Firestore is offline, fallback gracefully
          const fallbackUser: User = {
            id: fbUser.uid,
            name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Member',
            email: fbUser.email || '',
            avatar: fbUser.photoURL || undefined,
            memberTier: 'VIP Elite',
            memberPoints: 1000,
            joinedDate: 'Joined Today',
            preferredStyle: 'Streetwear',
            addresses: []
          };
          setUser(fallbackUser);
          localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(fallbackUser));
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Initialize local demo users & cached user
  useEffect(() => {
    try {
      const savedRegistered = localStorage.getItem(DEFAULT_USERS_KEY);
      if (!savedRegistered) {
        localStorage.setItem(DEFAULT_USERS_KEY, JSON.stringify(PRELOADED_USERS));
      }

      const savedCurrentUser = localStorage.getItem(CURRENT_USER_KEY);
      if (savedCurrentUser && !auth.currentUser) {
        setUser(JSON.parse(savedCurrentUser));
      }
    } catch {
      // fallback
    }
  }, []);

  const getRegisteredUsers = (): User[] => {
    try {
      const raw = localStorage.getItem(DEFAULT_USERS_KEY);
      return raw ? JSON.parse(raw) : PRELOADED_USERS;
    } catch {
      return PRELOADED_USERS;
    }
  };

  const saveRegisteredUsers = (users: User[]) => {
    try {
      localStorage.setItem(DEFAULT_USERS_KEY, JSON.stringify(users));
    } catch {
      // fallback
    }
  };

  const openAuthModal = (mode: AuthMode = 'signin') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const switchAuthMode = (mode: AuthMode) => {
    setAuthMode(mode);
  };

  const signInWithGoogle = async (): Promise<{ success: boolean; message: string }> => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;

      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {
        // ignore
      }

      setIsAuthModalOpen(false);
      return { success: true, message: `Welcome, ${fbUser.displayName || 'Member'}!` };
    } catch (err: any) {
      return { success: false, message: err?.message || 'Google Sign-In was cancelled.' };
    }
  };

  const signIn = (email: string, _password?: string) => {
    const trimmedEmail = email.trim().toLowerCase();
    const users = getRegisteredUsers();
    const found = users.find((u) => u.email.toLowerCase() === trimmedEmail);

    if (found) {
      setUser(found);
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(found));
      setIsAuthModalOpen(false);
      
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.8 },
          colors: ['#ffffff', '#00f2fe', '#ffd700']
        });
      } catch {
        // ignore
      }

      return { success: true, message: `Welcome back, ${found.name}!` };
    } else {
      const newUser: User = {
        id: 'user-' + Date.now(),
        name: trimmedEmail.split('@')[0].toUpperCase(),
        email: trimmedEmail,
        memberTier: 'Silver',
        memberPoints: 500,
        joinedDate: 'Joined Today',
        preferredStyle: 'Streetwear',
        addresses: []
      };

      const updated = [...users, newUser];
      saveRegisteredUsers(updated);
      setUser(newUser);
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(newUser));
      setIsAuthModalOpen(false);

      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.7 }
        });
      } catch {
        // ignore
      }

      return { success: true, message: `Account created for ${trimmedEmail}! 500 UrbanPoints unlocked.` };
    }
  };

  const signUp = ({
    name,
    email,
    preferredStyle,
  }: {
    name: string;
    email: string;
    password?: string;
    preferredStyle: User['preferredStyle'];
    subscribeNewsletter?: boolean;
  }) => {
    const trimmedEmail = email.trim().toLowerCase();
    const users = getRegisteredUsers();
    const existing = users.find((u) => u.email.toLowerCase() === trimmedEmail);

    if (existing) {
      setUser(existing);
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(existing));
      setIsAuthModalOpen(false);
      return { success: true, message: `Welcome back, ${existing.name}! You were already registered.` };
    }

    const newUser: User = {
      id: 'user-' + Date.now(),
      name: name.trim() || 'Urban Creator',
      email: trimmedEmail,
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(trimmedEmail)}`,
      memberTier: 'Silver',
      memberPoints: 600,
      joinedDate: 'Joined Today',
      preferredStyle: preferredStyle || 'Streetwear',
      addresses: []
    };

    const updatedList = [...users, newUser];
    saveRegisteredUsers(updatedList);
    setUser(newUser);
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(newUser));
    setIsAuthModalOpen(false);

    try {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#00f2fe', '#4facfe', '#ffffff', '#ffd700']
      });
    } catch {
      // ignore
    }

    return { success: true, message: `Welcome to UrbanStep, ${newUser.name}! +600 Welcome Points awarded.` };
  };

  const signOut = async () => {
    try {
      await fbSignOut(auth);
    } catch {
      // ignore
    }
    setUser(null);
    localStorage.removeItem(CURRENT_USER_KEY);
    setIsProfileDrawerOpen(false);
  };

  const updateProfile = async (data: Partial<User>) => {
    if (!user) return;
    const updated: User = { ...user, ...data };
    setUser(updated);
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(updated));

    const users = getRegisteredUsers();
    const listUpdated = users.map((u) => (u.id === user.id ? updated : u));
    saveRegisteredUsers(listUpdated);

    // Sync to Firestore if authenticated with Firebase
    if (auth.currentUser && auth.currentUser.uid === user.id) {
      try {
        const ref = doc(db, 'users', user.id);
        await updateDoc(ref, {
          name: updated.name,
          memberPoints: updated.memberPoints,
          memberTier: updated.memberTier,
          preferredStyle: updated.preferredStyle,
          updatedAt: new Date().toISOString()
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.UPDATE, `users/${user.id}`);
      }
    }
  };

  const addAddress = (address: Omit<ShippingAddress, 'id'>) => {
    if (!user) return;
    const newAddr: ShippingAddress = {
      ...address,
      id: 'addr-' + Date.now()
    };
    const currentAddresses = user.addresses || [];
    const updatedAddresses = address.isDefault
      ? currentAddresses.map((a) => ({ ...a, isDefault: false })).concat(newAddr)
      : [...currentAddresses, newAddr];

    updateProfile({ addresses: updatedAddresses });
  };

  const deleteAddress = (id: string) => {
    if (!user) return;
    const updatedAddresses = (user.addresses || []).filter((a) => a.id !== id);
    updateProfile({ addresses: updatedAddresses });
  };

  const quickDemoLogin = (role: 'asad' | 'fashionista' = 'asad') => {
    const targetEmail = role === 'asad' ? 'asadkhaan76762@gmail.com' : 'elena@urbanstep.com';
    signIn(targetEmail);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isAuthModalOpen,
        authMode,
        openAuthModal,
        closeAuthModal,
        switchAuthMode,
        signIn,
        signUp,
        signInWithGoogle,
        signOut,
        updateProfile,
        addAddress,
        deleteAddress,
        isProfileDrawerOpen,
        setIsProfileDrawerOpen,
        quickDemoLogin
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
