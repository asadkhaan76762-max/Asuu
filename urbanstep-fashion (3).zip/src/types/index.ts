export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  memberTier: 'Bronze' | 'Silver' | 'Gold' | 'VIP Elite';
  memberPoints: number;
  joinedDate: string;
  phone?: string;
  preferredStyle: 'Streetwear' | 'Techwear' | 'Minimalist' | 'Avant-Garde' | 'Sneakerhead';
  addresses: ShippingAddress[];
}

export interface ShippingAddress {
  id: string;
  isDefault: boolean;
  name: string;
  street: string;
  city: string;
  state: string;
  zip: string;
  country: string;
}

export interface Product {
  id: string;
  name: string;
  subtitle: string;
  category: 'Sneakers' | 'Outerwear' | 'Hoodies & Tops' | 'Pants' | 'Accessories';
  price: number;
  originalPrice?: number;
  tag?: 'NEW DROP' | 'EXCLUSIVE' | 'BESTSELLER' | 'LIMITED 50 PCS';
  image: string;
  gallery: string[];
  sizes: string[];
  colors: { name: string; hex: string }[];
  rating: number;
  reviewsCount: number;
  description: string;
  details: string[];
  inStock: boolean;
}

export interface CartItem {
  id: string; // unique item id combining productId + size + color
  product: Product;
  selectedSize: string;
  selectedColor: string;
  quantity: number;
}

export interface Order {
  id: string;
  date: string;
  items: CartItem[];
  totalAmount: number;
  status: 'Processing' | 'Shipped' | 'Out for Delivery' | 'Delivered';
  trackingNumber: string;
  shippingAddress: ShippingAddress;
}

export type AuthMode = 'signin' | 'signup' | 'forgot-password';

export interface BrandConfig {
  name: string;
  tagline: string;
  monogram: string;
  foundedYear: string;
  accentTheme: 'amber' | 'cyan' | 'rose' | 'emerald' | 'violet';
}

export interface RewardVoucher {
  id: string;
  code: string;
  amount: number;
  pointsCost: number;
  description: string;
  expiresIn: string;
}

export interface DropEvent {
  id: string;
  title: string;
  edition: string;
  date: string;
  countdownHours: number;
  image: string;
  tag: string;
  price: number;
}

