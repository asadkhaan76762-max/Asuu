import { Product } from '../types';

export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'KINETIC VORTEX 01 SNEAKER',
    subtitle: 'Chunky Sculpted Tech Runner',
    category: 'Sneakers',
    price: 240,
    originalPrice: 290,
    tag: 'NEW DROP',
    image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1000&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['US 7.5', 'US 8.5', 'US 9.5', 'US 10.5', 'US 11.5', 'US 12.5'],
    colors: [
      { name: 'Onyx Black', hex: '#111111' },
      { name: 'Chalk White', hex: '#e8e8e8' },
      { name: 'Volt Cyber', hex: '#b4f000' }
    ],
    rating: 4.9,
    reviewsCount: 142,
    description: 'Engineered for high-tempo urban mobility. Features multi-density decoupled EVA soles with responsive carbon fiber plate inserts and breathable ballistic mesh upper.',
    details: [
      'Carbon-fiber composite midfoot shank for torsional support',
      'Asymmetric lacing cage with reflective 3M cords',
      'Ortholite memory foam antimicrobial insole',
      'Custom UrbanStep tread pattern for multi-surface grip'
    ],
    inStock: true
  },
  {
    id: 'prod-2',
    name: 'SHADOW TECH SHELL PARKA',
    subtitle: '3-Layer Waterproof Tactical Jacket',
    category: 'Outerwear',
    price: 360,
    originalPrice: 420,
    tag: 'LIMITED 50 PCS',
    image: 'https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=1000&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Matte Jet', hex: '#161616' },
      { name: 'Olive Drab', hex: '#4b5320' },
      { name: 'Slate Gray', hex: '#4a5568' }
    ],
    rating: 5.0,
    reviewsCount: 89,
    description: 'Constructed from Japanese high-density ripstop nylon with taped seams. Features modular tactical strap sling system for hands-free carry when indoors.',
    details: [
      '20,000mm hydrostatic head waterproof rating',
      'Fidlock magnetic utility chest closures',
      'Internal detachable shoulder sling strap',
      'Storm hood with dual-axis cinching'
    ],
    inStock: true
  },
  {
    id: 'prod-3',
    name: 'OVERSIZED RAW-HEM ACID HOODIE',
    subtitle: '500 GSM Heavyweight French Terry',
    category: 'Hoodies & Tops',
    price: 155,
    tag: 'BESTSELLER',
    image: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=1000&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1578587018452-892bacefd3f2?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'Acid Washed Charcoal', hex: '#2c2e35' },
      { name: 'Dusty Taupe', hex: '#8a7968' },
      { name: 'Bone Ivory', hex: '#e3dfd7' }
    ],
    rating: 4.8,
    reviewsCount: 230,
    description: 'The definitive silhouette of UrbanStep. Custom milled 500 GSM loopback cotton, garment-dyed and mineral-washed for a vintage distressed patina.',
    details: [
      'Drop shoulder relaxed boxy drape',
      'Double-layered structured hood with no drawstrings',
      'Subtle tonal silicone high-density logo on nape',
      'Reinforced kangaroo pocket with internal phone pouch'
    ],
    inStock: true
  },
  {
    id: 'prod-4',
    name: 'AERO-CARGO MODULAR PANT',
    subtitle: '10-Pocket Tactical Wide-Leg Trouser',
    category: 'Pants',
    price: 195,
    tag: 'EXCLUSIVE',
    image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=1000&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['28', '30', '32', '34', '36'],
    colors: [
      { name: 'Stealth Black', hex: '#0f0f10' },
      { name: 'Desert Sand', hex: '#c2b280' }
    ],
    rating: 4.7,
    reviewsCount: 76,
    description: 'Versatile silhouette with ankle-toggle drawstrings allowing transition from stack wide-leg to tapered jogger. Durable DWR treated stretch twill.',
    details: [
      'Integrated webbing belt with quick-release aluminum cobra buckle',
      'Hidden zipper cargo bellows pockets',
      'Articulated knees for effortless mobility',
      'Reinforced seat and crotch gusset'
    ],
    inStock: true
  },
  {
    id: 'prod-5',
    name: 'CYBER-STAMP PLATFORM SNEAKER',
    subtitle: 'Lugged Vibram Outsole High-Top',
    category: 'Sneakers',
    price: 275,
    originalPrice: 320,
    tag: 'LIMITED 50 PCS',
    image: 'https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&w=1000&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1597045566677-8cf032ed6634?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['US 7.5', 'US 8.5', 'US 9.5', 'US 10.5', 'US 11.5'],
    colors: [
      { name: 'Monochrome Silver/Black', hex: '#404040' },
      { name: 'Solar Orange Accent', hex: '#ff5e00' }
    ],
    rating: 4.9,
    reviewsCount: 112,
    description: 'High-top silhouette crafted from premium Italian nubuck leather and transparent ripstop panels. Grounded on an oversized chunky sculpted platform.',
    details: [
      'Full grain Italian calf leather collar lining',
      'YKK waterproof lateral zipper for swift entry',
      'Custom stamped serial number on heel counter',
      'Heavy-duty Vibram Megagrip lugged rubber sole'
    ],
    inStock: true
  },
  {
    id: 'prod-6',
    name: 'MONOLITH CROSSBODY RIG',
    subtitle: 'Waterproof Ballistic Nylon Utility Bag',
    category: 'Accessories',
    price: 115,
    tag: 'BESTSELLER',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=1000&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['ONE SIZE'],
    colors: [
      { name: 'Pure Black', hex: '#000000' },
      { name: 'Reflective Camo', hex: '#374151' }
    ],
    rating: 4.9,
    reviewsCount: 94,
    description: 'Compact chest and sling pack with Fidlock V-buckle, waterproof AquaGuard zippers, and padded tablet compartment.',
    details: [
      '1000D Cordura ballistic nylon exterior',
      'Quick-release magnetic key leash',
      'Adjustable 3-point stabilizer chest harness',
      'Hidden passport and RFID blocking back sleeve'
    ],
    inStock: true
  },
  {
    id: 'prod-7',
    name: 'OVERDYED METALLIC BOMBER',
    subtitle: 'Reversible Flight Jacket with Down Insulation',
    category: 'Outerwear',
    price: 310,
    originalPrice: 380,
    tag: 'NEW DROP',
    image: 'https://images.unsplash.com/photo-1548883354-7622d03aca27?auto=format&fit=crop&w=1000&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1548883354-7622d03aca27?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Gunmetal Silver', hex: '#71717a' },
      { name: 'Deep Emerald', hex: '#064e3b' }
    ],
    rating: 4.8,
    reviewsCount: 63,
    description: 'Reversible MA-1 flight silhouette with iridized crinkle finish. Filled with ethically sourced 700 fill-power insulation for sub-zero warmth.',
    details: [
      'Reversible orange emergency contrast interior',
      'Heavy gauge two-way brass zip closure',
      'Cigarette sleeve pocket with crimson flight ribbon',
      'Thick rib knit collar, cuffs, and hem'
    ],
    inStock: true
  },
  {
    id: 'prod-8',
    name: 'SPECTRUM MATRIX SUNGLASSES',
    subtitle: 'Zero-Base Titanium Wrap Shades',
    category: 'Accessories',
    price: 140,
    tag: 'EXCLUSIVE',
    image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=1000&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['ONE SIZE'],
    colors: [
      { name: 'Mirror Chrome', hex: '#9ca3af' },
      { name: 'Obsidian Black', hex: '#111827' }
    ],
    rating: 4.6,
    reviewsCount: 48,
    description: 'Futuristic shield eyewear milled from aerospace-grade ultra-lightweight Japanese titanium. 100% UV400 polarized category 3 lens protection.',
    details: [
      'Frameless wrap aerodynamic curve',
      'Hypoallergenic adjustable silicone nose pads',
      'Laser engraved brand insignia on temples',
      'Includes hardshell leather carrying case and microfiber cloth'
    ],
    inStock: true
  }
];
